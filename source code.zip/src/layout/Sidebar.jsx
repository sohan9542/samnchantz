import React, { useState } from 'react'
import { BiLeftArrowCircle } from "react-icons/bi"
import { BsWindowDock } from "react-icons/bs"
import { MdDeviceHub } from "react-icons/md"
import { MdManageAccounts } from "react-icons/md"
import { BiChat } from "react-icons/bi"
import { VscProject } from "react-icons/vsc"

import { SiStatuspal } from "react-icons/si"
import { IoIosArrowRoundForward, IoIosArrowDown } from "react-icons/io"
import { MdOutlineAdminPanelSettings, MdOutlineArrowBackIos } from "react-icons/md"
import { AiOutlineTransaction } from "react-icons/ai"
import { IoFlaskOutline } from "react-icons/io5"
import { NavLink } from 'react-router-dom'
const Sidebar = ({
    setShowsidebar }) => {
    const [contractshow, setContractshow] = useState(false)
    const [transhow, setTranshow] = useState(false)
    return (
        <div className='fixed w-20 lg:w-60 p-2 shadow-lg z-30 bg-nr min-h-screen'>
            <div className='flex w-full items-center justify-between h-14 border-b'>
                <img
                    className="h-8 w-auto cursor-pointer"
                    src="https://tailwindui.com/img/logos/workflow-mark-indigo-500.svg"
                    alt="Workflow"

                />
                <BiLeftArrowCircle onClick={() => setShowsidebar(false)} className='cursor-pointer text-sr w-6 h-6' />
            </div>
            <div className='w-full hidden lg:flex py-4 flex-col items-center gap-1'>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/">  <BsWindowDock /> Overview</NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/device">  <MdDeviceHub /> Equipments</NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/labs">  <IoFlaskOutline /> Labs</NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/projects">  <VscProject /> Projects</NavLink>
                </div>
           
                <div className='w-full  flex items-center justify-center'>
                    <NavLink onClick={() => setContractshow(!contractshow)} exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-between px-2 text-white hover:text-sr w-full" to="/clist">
                        <div className='flex items-center gap-2'>
                            <MdManageAccounts /> Contracts</div> {!contractshow ? <MdOutlineArrowBackIos /> : <IoIosArrowDown className='h-5 w-5' />}</NavLink>
                </div>
                {
                    contractshow && <div className='w-full flex items-center flex-col text-sm'>
                        <div className='w-full pl-1 flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/clist">  <IoIosArrowRoundForward />Customers list</NavLink>
                        </div>
                        <div className='w-full pl-1 flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/vlist">  <IoIosArrowRoundForward />Vendors list</NavLink>
                        </div>
                        
                    </div>
                }
                <div className='w-full flex items-center justify-center'>
                    <NavLink onClick={() => setTranshow(!transhow)} exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-between px-2 text-white hover:text-sr w-full" to="/payment-history">
                        <div className='flex items-center gap-2'>
                            <AiOutlineTransaction /> Transactions</div> {!transhow ? <MdOutlineArrowBackIos /> : <IoIosArrowDown className='h-5 w-5' />}</NavLink>
                </div>
                {
                    transhow && <div className='w-full flex items-center flex-col text-sm'>
                        <div className='w-full pl-1 flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/payment-history">  <IoIosArrowRoundForward />Payment history</NavLink>
                        </div>
                        <div className='w-full pl-1 flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/wallet">  <IoIosArrowRoundForward />Wallet</NavLink>
                        </div>
                        <div className='w-full pl-1 flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/invoices">  <IoIosArrowRoundForward />Invoices</NavLink>
                        </div>
                    </div>
                }
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/inquiery">  <SiStatuspal /> Inquiries</NavLink>
                </div>
            
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to={"/chatbox/" + 0}>  <BiChat />ChatBox</NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink  exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-between px-2 text-white hover:text-sr w-full" to="/manage-roles">
                        <div className='flex items-center gap-2'>
                            <MdOutlineAdminPanelSettings /> Admin Panel</div> </NavLink>
                </div>

               
            </div>
            <div className='w-full flex lg:hidden py-4 flex-col items-center  gap-1'>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-2 text-white hover:text-sr w-full" to="/">  <BsWindowDock /></NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-2 text-white hover:text-sr w-full" to="/device">  <MdDeviceHub /> </NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-2 text-white hover:text-sr w-full" to="/labs">  <IoFlaskOutline /> </NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-2 text-white hover:text-sr w-full" to="/projects">  <VscProject /> </NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink onClick={() => setContractshow(!contractshow)} exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-2 text-white hover:text-sr w-full" to="/clist">
                        <div className='flex items-center justify-center'>
                            <MdManageAccounts /> </div></NavLink>
                </div>
                {
                    contractshow && <div className='w-full flex items-center flex-col text-xs'>
                        <div className='w-full flex items-center '>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/clist">  <IoIosArrowRoundForward />C-list</NavLink>
                        </div>
                        <div className='w-full flex items-center '>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center gap-2 px-2 text-white hover:text-sr w-full" to="/vlist">  <IoIosArrowRoundForward />V-list</NavLink>
                        </div>
                        
                    </div>
                }
     <div className='w-full flex items-center justify-center'>
                    <NavLink onClick={() => setTranshow(!transhow)} exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-2 text-white hover:text-sr w-full" to="/payment-history">
                        <div className='flex items-center gap-2'>
                            <AiOutlineTransaction /></div></NavLink>
                </div>
                {
                    transhow && <div className='w-full flex items-center flex-col text-xs'>
                        <div className='w-full  flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center  text-white hover:text-sr w-full" to="/payment-history">  <IoIosArrowRoundForward />P-history</NavLink>
                        </div>
                        <div className='w-full flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center   text-white hover:text-sr w-full" to="/wallet">  <IoIosArrowRoundForward />Wallet</NavLink>
                        </div>
                        <div className='w-full flex items-center justify-center'>
                            <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center  px-1  text-white hover:text-sr w-full" to="/invoices">  <IoIosArrowRoundForward />Invoices</NavLink>
                        </div>
                    </div>
                }

                
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-2 text-white hover:text-sr w-full" to="/inquiery">  <SiStatuspal /></NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 flex items-center justify-center px-1 text-white hover:text-sr w-full" to={"/chatbox/" + 0}> <BiChat /></NavLink>
                </div>
                <div className='w-full  flex items-center justify-center'>
                    <NavLink exact activeClassName='hvr tc w-full' className="py-2 justify-center flex items-center px-2 text-white hover:text-sr w-full" to="/manage-roles">
                        <div className='flex items-center gap-2'>
                            <MdOutlineAdminPanelSettings /></div> </NavLink>
                </div>

               

            </div>
        </div>
    )
}

export default Sidebar
