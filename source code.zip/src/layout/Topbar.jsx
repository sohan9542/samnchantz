/* This example requires Tailwind CSS v2.0+ */
import { Fragment } from 'react'
import { Disclosure, Menu, Transition } from '@headlessui/react'
import { BellIcon, MenuIcon, XIcon } from '@heroicons/react/outline'
import { NavLink } from 'react-router-dom'
import { BiSearch, BiRightArrowCircle, BiMailSend, BiChat } from "react-icons/bi"
import { RiShareForwardLine } from "react-icons/ri"
import { BsPlusLg } from "react-icons/bs"
import { BsPlusSquareDotted } from "react-icons/bs"
import { AiOutlineQrcode } from "react-icons/ai"
import { FiActivity } from "react-icons/fi"
import { RiContactsBook2Fill } from "react-icons/ri"
import { MdManageAccounts } from "react-icons/md"
import { FiMail, FiSettings, FiHelpCircle } from "react-icons/fi"
import { Link } from 'react-router-dom'
function classNames(...classes) {
    return classes.filter(Boolean).join(' ')
}
const Topbar = ({ setShowsidebar, showsidebar }) => {
    return (
        <Disclosure as="nav" className="bg-white shadow-md">
            {({ open }) => (
                <>
                    <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
                        <div className="relative flex items-center justify-between h-16">
                            {!showsidebar && <div>
                                <BiRightArrowCircle onClick={() => setShowsidebar(true)} className="text-pr h-6 w-6 cursor-pointer" />
                            </div>}
                            <div className={!showsidebar ? "absolute inset-y-0 left-8 flex items-center sm:hidden" : "absolute inset-y-0 left-0 flex items-center sm:hidden"}>
                                {/* Mobile menu button*/}
                                <Disclosure.Button className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                                    <span className="sr-only">Open main menu</span>
                                    {open ? (
                                        <XIcon className="block h-6 w-6" aria-hidden="true" />
                                    ) : (
                                        <MenuIcon className="block h-6 w-6" aria-hidden="true" />
                                    )}
                                </Disclosure.Button>
                            </div>
                            <div className="flex-1 flex items-center justify-center sm:items-stretch sm:justify-start">

                                <div className="hidden sm:block sm:ml-6">
                                    <div className="flex space-x-4  gap-1 lg:gap-0">
                                        <Menu as="div" className="ml-3 relative">
                                            <div>
                                                <Menu.Button className=" flex text-sm rounded-full focus:outline-none ">
                                                    <button
                                                        type="button"
                                                        className="p-1 border-2 border-pr bg-pr  text-white focus:outline-none "
                                                    >

                                                        Industries
                                                    </button>
                                                </Menu.Button>
                                            </div>
                                            <Transition
                                                as={Fragment}
                                                enter="transition ease-out duration-100"
                                                enterFrom="transform opacity-0 scale-95"
                                                enterTo="transform opacity-100 scale-100"
                                                leave="transition ease-in duration-75"
                                                leaveFrom="transform opacity-100 scale-100"
                                                leaveTo="transform opacity-0 scale-95"
                                            >
                                                <Menu.Items style={{ marginLeft: "10px" }} className="absolute mt-2 w-48 rounded-md shadow-lg py-1 bg-white">
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                Pharmaceutical
                                                            </a>
                                                        )}
                                                    </Menu.Item>
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                CRO
                                                            </a>
                                                        )}
                                                    </Menu.Item>
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                Clinical
                                                            </a>
                                                        )}
                                                    </Menu.Item>
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                Diagnostic
                                                            </a>
                                                        )}
                                                    </Menu.Item>
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                Food
                                                            </a>
                                                        )}
                                                    </Menu.Item>
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                Agricultural
                                                            </a>
                                                        )}
                                                    </Menu.Item>
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                Chemical
                                                            </a>
                                                        )}
                                                    </Menu.Item>
                                                    <Menu.Item>
                                                        {({ active }) => (
                                                            <a
                                                                href="#"
                                                                className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                            >
                                                                Oil/Gas
                                                            </a>
                                                        )}
                                                    </Menu.Item>

                                                </Menu.Items>
                                            </Transition>

                                        </Menu>
                                        <div className='flex items-center'>
                                            <input placeholder='Type to search' type="text" className='bg-gray-100 w-72 lg:w-96 py-2 px-2 outline-none text-sm' />
                                            <button className='p-2 h-full bg-gray-100'><BiSearch /></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">

                                <Menu as="div" className="ml-3 relative">
                                    <div>
                                        <Menu.Button className=" flex text-sm rounded-full focus:outline-none ">
                                            <button
                                                type="button"
                                                className=" p-1 rounded-full text-pr focus:outline-none "
                                            >

                                                <AiOutlineQrcode className="h-6 w-6" aria-hidden="true" />
                                            </button>
                                        </Menu.Button>
                                    </div>
                                    <Transition
                                        as={Fragment}
                                        enter="transition ease-out duration-100"
                                        enterFrom="transform opacity-0 scale-95"
                                        enterTo="transform opacity-100 scale-100"
                                        leave="transition ease-in duration-75"
                                        leaveFrom="transform opacity-100 scale-100"
                                        leaveTo="transform opacity-0 scale-95"
                                    >
                                        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Teams
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Projects
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Tasks
                                                    </a>
                                                )}
                                            </Menu.Item>

                                        </Menu.Items>
                                    </Transition>

                                </Menu>
                                <Menu as="div" className="ml-3 relative">
                                    <div>
                                        <Menu.Button className=" flex text-sm rounded-full focus:outline-none ">
                                            <button
                                                type="button"
                                                className=" p-1 rounded-full text-pr focus:outline-none "
                                            >

                                                <BsPlusSquareDotted className="h-6 w-6" aria-hidden="true" />
                                            </button>
                                        </Menu.Button>
                                    </div>
                                    <Transition
                                        as={Fragment}
                                        enter="transition ease-out duration-100"
                                        enterFrom="transform opacity-0 scale-95"
                                        enterTo="transform opacity-100 scale-100"
                                        leave="transition ease-in duration-75"
                                        leaveFrom="transform opacity-100 scale-100"
                                        leaveTo="transform opacity-0 scale-95"
                                    >
                                        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <Link
                                                        to="/add-labs"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        New Lab
                                                    </Link>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <Link
                                                        to="/add-device"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        New Equipments
                                                    </Link>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        New Project
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <Link
                                                        to="/manage-users"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        New Team / User
                                                    </Link>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        New Issue
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        New Industry
                                                    </a>
                                                )}
                                            </Menu.Item>

                                        </Menu.Items>
                                    </Transition>
                                </Menu>
                                {/* Profile dropdown */}
                                <Menu as="div" className="ml-3 relative">

                                    <div>
                                        <Menu.Button className=" flex text-sm rounded-full focus:outline-none ">
                                            <button
                                                type="button"
                                                className=" p-1 rounded-full text-pr focus:outline-none"
                                            >

                                                <BellIcon className="h-6 w-6" aria-hidden="true" />
                                            </button>
                                        </Menu.Button>
                                    </div>
                                    <Transition
                                        as={Fragment}
                                        enter="transition ease-out duration-100"
                                        enterFrom="transform opacity-0 scale-95"
                                        enterTo="transform opacity-100 scale-100"
                                        leave="transition ease-in duration-75"
                                        leaveFrom="transform opacity-100 scale-100"
                                        leaveTo="transform opacity-0 scale-95"
                                    >
                                        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        View Notifications
                                                    </a>
                                                )}
                                            </Menu.Item>

                                        </Menu.Items>
                                    </Transition>
                                </Menu>
                                <Menu as="div" className="ml-3 relative">
                                    <div>
                                        <Menu.Button className=" flex text-sm rounded-full focus:outline-none ">
                                            <button
                                                type="button"
                                                className=" p-1 rounded-full text-pr focus:outline-none "
                                            >

                                                <BiMailSend className="h-6 w-6" aria-hidden="true" />
                                            </button>

                                        </Menu.Button>
                                    </div>
                                    <Transition
                                        as={Fragment}
                                        enter="transition ease-out duration-100"
                                        enterFrom="transform opacity-0 scale-95"
                                        enterTo="transform opacity-100 scale-100"
                                        leave="transition ease-in duration-75"
                                        leaveFrom="transform opacity-100 scale-100"
                                        leaveTo="transform opacity-0 scale-95"
                                    >
                                        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Compose
                                                    </a>
                                                )}
                                            </Menu.Item>

                                        </Menu.Items>
                                    </Transition>
                                </Menu>
                                <Menu as="div" className="ml-3 relative">
                                    <div>
                                        <Menu.Button className=" flex text-sm rounded-full focus:outline-none ">
                                            <button
                                                type="button"
                                                className=" p-1 rounded-full text-pr focus:outline-none focus:ring-white"
                                            >

                                                <RiShareForwardLine className="h-6 w-6" aria-hidden="true" />
                                            </button>
                                        </Menu.Button>
                                    </div>
                                    <Transition
                                        as={Fragment}
                                        enter="transition ease-out duration-100"
                                        enterFrom="transform opacity-0 scale-95"
                                        enterTo="transform opacity-100 scale-100"
                                        leave="transition ease-in duration-75"
                                        leaveFrom="transform opacity-100 scale-100"
                                        leaveTo="transform opacity-0 scale-95"
                                    >
                                        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Share Documents
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', 'block px-4 py-2 text-sm text-gray-700')}
                                                    >
                                                        Ideas
                                                    </a>
                                                )}
                                            </Menu.Item>
                                        </Menu.Items>

                                    </Transition>
                                </Menu>
                                <Menu as="div" className="ml-3 relative">
                                    <div>
                                        <Menu.Button className=" flex items-center gap-2 border p-1">

                                            <img
                                                className="h-8 w-8 rounded-full"
                                                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                                                alt=""
                                            />
                                            <div className='lg:flex flex-col hidden'>
                                                <p className='text-gray-500 text-sm'>Iot SuperAdmin</p>
                                                <p className='text-xs text-gray-300'>SuperAdmin</p>
                                            </div>
                                        </Menu.Button>
                                    </div>
                                    <Transition
                                        as={Fragment}
                                        enter="transition ease-out duration-100"
                                        enterFrom="transform opacity-0 scale-95"
                                        enterTo="transform opacity-100 scale-100"
                                        leave="transition ease-in duration-75"
                                        leaveFrom="transform opacity-100 scale-100"
                                        leaveTo="transform opacity-0 scale-95"
                                    >
                                        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-72 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center gap-2 py-2 text-sm text-gray-700')}
                                                    >
                                                        <MdManageAccounts className='text-green-500 h-5 w-5' /> Profile
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center justify-between py-2 text-sm text-gray-700')}
                                                    >
                                                        <div className='w-full flex items-center gap-2'>
                                                            <FiMail className='text-purple-500 h-5 w-5' /> Inbox
                                                        </div>
                                                        <div>
                                                            <p className='bg-purple-500 px-2 py-0 rounded-sm text-white'>1</p>
                                                        </div>
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center gap-2 py-2 text-sm text-gray-700')}
                                                    >
                                                        <FiSettings className='text-blue-500 h-5 w-5' /> Settings
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center gap-2 py-2 text-sm text-gray-700')}
                                                    >
                                                        <FiActivity className=' h-5 w-5 text-green-500' /> Activity
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center gap-2 py-2 text-sm text-gray-700')}
                                                    >
                                                        <RiContactsBook2Fill className='h-5 w-5 text-indigo-600' /> Contacts
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center gap-2 py-2 text-sm text-gray-700')}
                                                    >
                                                        <FiHelpCircle className='text-yellow-500 h-5 w-5' /> Need Help?
                                                    </a>
                                                )}
                                            </Menu.Item>
                                            <div className='grid grid-cols-2'>
                                                <Menu.Item>
                                                    {({ active }) => (
                                                        <a
                                                            href="#"
                                                            className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center justify-center py-2 text-sm text-gray-700')}
                                                        >
                                                            <div className='flex items-center flex-col justify-center'>
                                                                <BiChat className='text-pr h-5 w-5' />
                                                                Chats
                                                            </div>

                                                        </a>
                                                    )}
                                                </Menu.Item>
                                                <Menu.Item>
                                                    {({ active }) => (
                                                        <a
                                                            href="#"
                                                            className={classNames(active ? 'bg-gray-100' : '', ' px-4 flex items-center justify-center py-2 text-sm text-gray-700')}
                                                        >

                                                            <div className='flex text-center items-center flex-col gap-1 text-xs justify-center'>
                                                                <BsPlusLg className='text-pr h-4 w-4' />
                                                                Compose New
                                                            </div>
                                                        </a>
                                                    )}
                                                </Menu.Item>
                                            </div>
                                        </Menu.Items>
                                    </Transition>
                                </Menu>
                            </div>
                        </div>
                    </div>

                    <Disclosure.Panel className="sm:hidden">
                        <div className="px-2 pt-2 pb-2 flex items-center gap-2">
                            <NavLink exact activeClassName='bg-hr tc' to="/industry" className="p-2 text-gray-400 border-2 text-xs border-yellow-100">Speciality</NavLink>
                            <div className='flex items-center'>
                                <input placeholder='Type to search' type="text" className='bg-gray-100 p-2 outline-none' />
                                <button className='p-2 h-full bg-gray-100'><BiSearch className='h-6 w-6' /></button>
                            </div>
                        </div>
                    </Disclosure.Panel>
                </>
            )}
        </Disclosure>
    )
}

export default Topbar

