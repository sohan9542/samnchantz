import React, { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";
import Topbar from './layout/Topbar';
import Sidebar from './layout/Sidebar';
import Dashboard from './component/Dashboard';
import Device from './component/device/Device';
import AddDevice from './component/device/AddDevice';
import Cdashbaord from './component/device/Cdashbaord';
import Calibration from './component/device/Calibration';
import Mylabs from './component/Labs/Mylabs';
import AllLabs from './component/Labs/AllLabs';
import AddLabs from './component/Labs/AddLabs';
import Myorders from './component/Labs/Myorders';
import Clist from './component/Contracts/Clist';
import Vlist from './component/Contracts/Vlist';
import PaymentHistory from './component/Transaction/PaymentHistory';
import Invoices from './component/Transaction/Invoices';
import Wallet from './component/Transaction/Wallet';
import Inquiries from './component/Inquiries/Inquiries';
import Chatbox from './component/Chatbox/Chatbox';
import DeviceDashboard from './component/device/DeviceDashboard';
import Booking from './component/Checkout/Booking';
import Payment from './component/Checkout/Payment';
import Admin from './component/AdminPanel/Admin';
import ActiveUser from './component/AdminPanel/Activeusers';


const App = () => {
  const [showsidebar, setShowsidebar] = useState(true)
  return (
    <div className='bg-tr min-h-screen'>
      <Router>
        {showsidebar && <Sidebar
          setShowsidebar={setShowsidebar} />}
        <div className={showsidebar ? 'ml-20 lg:ml-60' : "ml-0"}>
          <Topbar
            showsidebar={showsidebar}
            setShowsidebar={setShowsidebar} />
        </div>
        <div className={showsidebar ? 'ml-20 lg:ml-60' : "ml-0"}>
          <Switch>
            <Route exact path="/">
              <Dashboard />
            </Route>
            <Route  path="/device">
              <Device />
            </Route>
            <Route path="/add-device">
              <AddDevice />
            </Route>
            <Route path="/add-dashboard">
              <Cdashbaord />
            </Route>
            <Route path="/device-calibrations">
              <Calibration />
            </Route>
            <Route path="/labs">
              <AllLabs />
            </Route>
            <Route path="/my-labs">
              <Mylabs />
            </Route>
            <Route path="/add-labs">
              <AddLabs />
            </Route>
            <Route path="/my-orders">
              <Myorders />
            </Route>
            <Route path="/clist">
              <Clist />
            </Route>
            <Route path="/vlist">
              <Vlist />
            </Route>
            <Route path="/payment-history">
              <PaymentHistory />
            </Route>
            <Route path="/invoices">
              <Invoices />
            </Route>
            <Route path="/wallet">
              <Wallet />
            </Route>
            <Route path="/inquiery">
              <Inquiries />
            </Route>
            <Route path="/chatbox/:chatid">
              <Chatbox />
            </Route>
            <Route path="/device-dashboard/:dashid">
              <DeviceDashboard />
            </Route>
            <Route path="/booking">
              <Booking />
            </Route>
            <Route path="/checkout">
              <Payment />
            </Route>
            <Route path="/manage-roles">
              <Admin />
            </Route>
            <Route path="/manage-users">
              <ActiveUser />
            </Route>
          </Switch>
        </div>
      </Router>
    </div>
  )
}

export default App
