import React from 'react'
import { NavLink, Link } from 'react-router-dom'
import { BsThreeDotsVertical } from "react-icons/bs"
import { BiLocationPlus } from "react-icons/bi"
import { BsArrowRightShort } from "react-icons/bs"
import { MdOutlineHomeRepairService } from "react-icons/md"
import { Menu, Transition } from '@headlessui/react'
import { Fragment } from 'react'
import { AiTwotoneStar, AiOutlineDollarCircle, AiOutlineCalendar } from "react-icons/ai"
const AllLabs = () => {
    function classNames(...classes) {
        return classes.filter(Boolean).join(' ')
    }
    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div className='flex items-start justify-center gap-2 pb-2 border-b'>
                    <NavLink exact to="/labs" activeClassName='bg-pr pr' className='border px-2 py-1 text-sm font-medium cursor-pointer hover:text-sr text-sr'>
                        Explore Labs
                    </NavLink>
                    <NavLink exact to="/my-labs" activeClassName='bg-pr pr' className='border px-2 py-1 text-sm font-medium cursor-pointer hover:text-sr text-sr'>
                        My Labs
                    </NavLink>
                    <NavLink exact to="/my-orders" activeClassName='bg-pr pr' className='border px-2 py-1 text-sm font-medium cursor-pointer hover:text-sr text-sr'>
                        My Orders
                    </NavLink>
                    <NavLink exact to="/add-labs" activeClassName='bg-pr pr' className='border px-2 py-1 text-sm font-medium cursor-pointer hover:text-sr text-sr'>
                        Add Labs
                    </NavLink>
                </div>
                <div className="flex pt-4 flex-col overflow-hidden">
                    <h1 className='text-center text-xl text-pr w-full pb-4 flex items-center gap-1 justify-center'>Explore Labs <BsArrowRightShort /></h1>
                    <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className="shadow overflow-hidden border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Listed by
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Description
                                            </th>

                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Accreditations
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Visibility
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Status
                                            </th>


                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Action
                                            </th>

                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">
                                        <tr>
                                            <td className="whitespace-nowrap">
                                                <div >
                                                    <img className='w-72' src="https://cdn.labmanager.com/assets/articleNo/2352/iImg/5015/11bf19af-3e36-4fe0-991c-0ec7e91f9f5e-mar18-ls-future-640x360.jpg" alt="" />
                                                    <div className='w-72  pt-2'>
                                                        <h6 className='text-pr text-lg '>Alexa Diagostic Lab</h6>

                                                        <p className='text-gray-500 flex items-center text-sm gap-1 font-medium pt-1'> <BiLocationPlus />Lab location</p>
                                                        <p className='text-gray-500 flex items-center text-sm font-medium gap-1 py-1'><AiOutlineCalendar /> Date Added: </p>
                                                        <div className='flex items-center gap-2 border-b pb-2'>
                                                            <div className="flex items-center text-pr">
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar className='text-blue-200' />
                                                                <p className='text-sr text-xs'> (4.5)</p>
                                                            </div>

                                                        </div>
                                                        <div className='flex justify-between flex-wrap py-2 px-1'>
                                                            <div className='flex items-center gap-1 flex-col'>
                                                                <div className='px-2 bg-pr text-sr flex items-center py-1 rounded-full'>
                                                                    <AiOutlineDollarCircle />
                                                                </div>
                                                                <p className='text-sm font-medium text-pr'>$00/Monthly</p>
                                                            </div>
                                                            <div className='flex items-center  gap-1 flex-col'>
                                                                <div className='px-2 bg-pr text-sr flex items-center py-1 rounded-full'>
                                                                    <MdOutlineHomeRepairService />
                                                                </div>
                                                                <p className='text-sm font-medium text-pr'>No Service</p>
                                                            </div>
                                                            <div className='flex items-center gap-1 flex-col'>
                                                                <div className='px-2 bg-pr text-sr text-xs flex items-center py-1 rounded-md'>
                                                                    Expertise
                                                                </div>
                                                                <button className='px-2 bg-blue-900 text-sr text-xs flex items-center py-1 rounded-md'>
                                                                    Book Now
                                                                </button>
                                                            </div>

                                                        </div>


                                                    </div>
                                                </div>

                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>Description</p>
                                            </td>

                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>accreditations</p>
                                            </td>
                                            <td className="py-4 whitespace-nowrap">


                                                <select
                                                    className="block w-full border border-gray-300 bg-white text-pr px-2 py-1 shadow-sm sm:text-sm"
                                                >
                                                    <option>Private</option>
                                                    <option>Internal</option>
                                                    <option>Public</option>

                                                </select>

                                            </td>
                                            <td className="py-4 whitespace-nowrap">


                                                <select
                                                    className="block w-full border border-gray-300 bg-white text-pr px-2 py-1 shadow-sm sm:text-sm"
                                                >
                                                    <option>Available</option>
                                                    <option>Booked</option>

                                                </select>

                                            </td>

                                            <td className="px-6 py-4 whitespace-nowrap">

                                                <Menu as="div" className="relative inline-block text-left">
                                                    <div>
                                                        <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                            <BsThreeDotsVertical className='h-6 w-6' />
                                                        </Menu.Button>
                                                    </div>

                                                    <Transition
                                                        as={Fragment}
                                                        enter="transition ease-out duration-100"
                                                        enterFrom="transform opacity-0 scale-95"
                                                        enterTo="transform opacity-100 scale-100"
                                                        leave="transition ease-in duration-75"
                                                        leaveFrom="transform opacity-100 scale-100"
                                                        leaveTo="transform opacity-0 scale-95"
                                                    >
                                                        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-40 z-50 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                                            <div className="py-1">
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <Link
                                                                            to="/booking"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Book It Now
                                                                        </Link>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Details
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Edit
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Delete
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Share                                                    </a>
                                                                    )}
                                                                </Menu.Item>

                                                            </div>
                                                        </Menu.Items>
                                                    </Transition>
                                                </Menu>
                                            </td>



                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    )
}

export default AllLabs
