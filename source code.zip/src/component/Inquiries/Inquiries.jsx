import React from 'react'
const Inquiries = () => {
    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div>
                    <h1 className='text-xl text-pr w-full pb-4 pt-4 pl-3'>We can help you list your lab, just send us about short message.</h1>
                    <div >
                        <form action="#" method="POST">
                            <div className="shadow overflow-hidden sm:rounded-md">
                                <div className="px-4 py-3 bg-white sm:p-6">
                                    <div className='pb-3'>
                                        <label htmlFor="first-name" className="block text-sm font-medium pb-3 text-gray-700">
                                            Choose Your Lab Type <span className='text-pr'>*</span>
                                        </label>
                                        <div className='flex items-center flex-wrap gap-4'>
                                            <div className="flex items-start">
                                                <div className="flex items-center h-5">
                                                    <input
                                                        id="comments"
                                                        name="comments"
                                                        type="checkbox"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                                                    />
                                                </div>
                                                <div className="ml-3 text-sm">
                                                    <label htmlFor="comments" className="font-medium text-gray-700">
                                                        Pharmaceutical
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="flex items-start">
                                                <div className="flex items-center h-5">
                                                    <input
                                                        id="comments"
                                                        name="comments"
                                                        type="checkbox"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                                                    />
                                                </div>
                                                <div className="ml-3 text-sm">
                                                    <label htmlFor="comments" className="font-medium text-gray-700">
                                                        Diagnostics
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="flex items-start">
                                                <div className="flex items-center h-5">
                                                    <input
                                                        id="comments"
                                                        name="comments"
                                                        type="checkbox"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                                                    />
                                                </div>
                                                <div className="ml-3 text-sm">
                                                    <label htmlFor="comments" className="font-medium text-gray-700">
                                                        Clinical Trials
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="flex items-start">
                                                <div className="flex items-center h-5">
                                                    <input
                                                        id="comments"
                                                        name="comments"
                                                        type="checkbox"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                                                    />
                                                </div>
                                                <div className="ml-3 text-sm">
                                                    <label htmlFor="comments" className="font-medium text-gray-700">
                                                        Food
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="flex items-start">
                                                <div className="flex items-center h-5">
                                                    <input
                                                        id="comments"
                                                        name="comments"
                                                        type="checkbox"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                                                    />
                                                </div>
                                                <div className="ml-3 text-sm">
                                                    <label htmlFor="comments" className="font-medium text-gray-700">
                                                        Contract research
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div >
                                        <div className='mt-2 grid grid-cols-1 lg:grid-cols-2 gap-2'>
                                            <div>
                                                <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                                                    Name*
                                                </label>
                                                <input
                                                    type="text"
                                                    placeholder='John Deo'
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                                                    Email*
                                                </label>
                                                <input
                                                    type="email"
                                                    placeholder='Enter email'
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                        </div>
                                        <div className='grid grid-cols-1 lg:grid-cols-2 gap-2'>
                                            <div className='mt-2 '>
                                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                    Phone*
                                                </label>
                                                <input
                                                    type="number"
                                                    placeholder='+91'
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                            <div className='mt-2'>
                                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                    Company Name*
                                                </label>
                                                <input
                                                    type="text"
                                                    placeholder='Example'
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                        </div>
                                        <div className='grid grid-cols-1 lg:grid-cols-2 gap-2'>
                                            <div className=" pt-2">
                                                <label htmlFor="country" className="block text-sm font-medium text-gray-700">
                                                    Country
                                                </label>
                                                <select
                                                    className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm sm:text-sm"
                                                >
                                                    <option>Country1</option>
                                                    <option>Country2</option>

                                                </select>
                                            </div>
                                            <div className=" pt-2">
                                                <label htmlFor="country" className="block text-sm font-medium text-gray-700">
                                                    City
                                                </label>
                                                <select
                                                    className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm sm:text-sm"
                                                >
                                                    <option>City1</option>
                                                    <option>City2</option>

                                                </select>
                                            </div>
                                        </div>
                                        <div className='mt-2'>
                                            <label htmlFor="about" className="block text-sm font-medium text-gray-700">
                                                Message*
                                            </label>
                                            <div className="mt-1">
                                                <textarea
                                                    id="about"
                                                    placeholder='Write Short Message'
                                                    name="about"
                                                    rows={3}
                                                    className="shadow-sm  mt-1 block w-full sm:text-sm border border-gray-300 rounded-md p-2 h-32"

                                                />
                                            </div>

                                        </div>


                                    </div>
                                </div>
                                <div className="w-full">
                                    <button
                                        type="submit"
                                        className="w-full bg-pr text-white py-3 hover:bg-blue-900"
                                    >
                                        Send Inquiry
                                    </button>

                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

        </div>
    )
}

export default Inquiries
