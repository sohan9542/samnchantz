import React from 'react'
import { NavLink } from 'react-router-dom'
import { BsThreeDotsVertical } from "react-icons/bs"
import { BiLocationPlus } from "react-icons/bi"
import { BsArrowRightShort } from "react-icons/bs"
import { MdOutlineHomeRepairService } from "react-icons/md"
import { Menu, Transition } from '@headlessui/react'
import { Fragment } from 'react'
import { AiTwotoneStar, AiOutlineDollarCircle,AiOutlineCalendar } from "react-icons/ai"
import { Link } from 'react-router-dom'
const Equipments = () => {
    function classNames(...classes) {
        return classes.filter(Boolean).join(' ')
    }
    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div className='flex items-start justify-center gap-2 pb-2 border-b'>
                    <NavLink exact to="/device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        All Equipments
                    </NavLink>
                    <NavLink exact to="/add-dashboard" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Dashboard
                    </NavLink>
                    <NavLink exact to="/device-calibrations" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Equipments Calibrations
                    </NavLink>
                    <NavLink exact to="/add-device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        Add Equipments
                    </NavLink>
                </div>
                <div className="flex pt-4 flex-col overflow-hidden">
                    <h1 className='text-center text-xl text-pr w-full pb-4 flex items-center justify-center gap-1'>All Equipments <BsArrowRightShort /></h1>
                    <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className="shadow border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Lab Name
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Description
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Visibility
                                            </th>
                                           
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Status
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Location
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Last Connected
                                            </th>
                                          
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Action
                                            </th>

                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">

                                        <tr >

                                            <td className="whitespace-nowrap">
                                                <div className='p-2'>
                                                    <img  className='w-80' src="https://t3.ftcdn.net/jpg/02/58/89/90/360_F_258899001_68CalsKTRk6PZQgWH9JhR4heBlncCko9.jpg" alt="" />
                                                    <div className='w-full pt-2'>
                                                        <h6 className='text-pr text-lg '>Equipments Name</h6>
                                                        <p className='text-gray-500 flex items-center text-sm gap-1 font-medium py-1'> <BiLocationPlus />Lab location</p>
                                                        <p className='text-gray-500 flex items-center text-sm font-medium gap-1'><AiOutlineCalendar/> Date Added : </p>
                                                        <div className='flex items-center gap-2 border-b py-1'>
                                                            <div className="flex items-center text-pr">
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar />
                                                                <AiTwotoneStar className='text-blue-200' />
                                                                <p className='text-sr text-xs'> (4.5)</p>
                                                            </div>

                                                        </div>
                                                        <div className='flex justify-between gap-3 py-2'>
                                                            <div className='flex items-center gap-2 flex-col'>
                                                                <div className='px-2 bg-pr text-sr flex items-center py-1 rounded-md'>
                                                                    <AiOutlineDollarCircle />
                                                                </div>
                                                                <p className='text-xs font-medium text-pr'>$000</p>
                                                            </div>
                                                            <div className='flex items-center gap-2  flex-col'>
                                                                <div className='px-2 bg-pr text-sr flex items-center py-1 rounded-md'>
                                                                    <MdOutlineHomeRepairService />
                                                                </div>
                                                                <p className='text-xs font-medium text-pr'>No Service</p>
                                                            </div>
                                                            <div className='flex items-center  flex-col gap-2'>
                                                                <div className='px-2 bg-pr text-sr text-xs flex items-center py-1 rounded-md'>
                                                                    Expertise
                                                                </div>
                                                                <button className='px-2 bg-blue-900 text-sr text-xs flex items-center py-1 rounded-md'>
                                                                    Book Now
                                                                </button>

                                                            </div>

                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p></p>
                                            </td>
                                            <td className="py-4 whitespace-nowrap">
                                                <select
                                                    className="block w-full border border-gray-300 bg-white text-pr px-2 py-1 shadow-sm sm:text-sm"
                                                >
                                                    <option>Public</option>
                                                    <option>Private</option>
                                                    <option>Internal</option>

                                                </select>
                                            </td>
                                           
                                            <td className="py-4 whitespace-nowrap">
                                                <select
                                                    className="block w-full border border-gray-300 bg-white text-pr px-2 py-1 shadow-sm sm:text-sm"
                                                >

                                                    <option>Online</option>
                                                    <option>Offline</option>

                                                </select>
                                            </td>
                                            <td className="py-4 px-6 whitespace-nowrap">
                                                <p>device location</p>
                                            </td>
                                           
                                            <td className="py-4 px-6 whitespace-nowrap">
                                                <p>01/01/2020</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <Menu as="div" className="relative inline-block text-left">
                                                    <div>
                                                        <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                            <BsThreeDotsVertical className='h-6 w-6' />
                                                        </Menu.Button>
                                                    </div>

                                                    <Transition
                                                        as={Fragment}
                                                        enter="transition ease-out duration-100"
                                                        enterFrom="transform opacity-0 scale-95"
                                                        enterTo="transform opacity-100 scale-100"
                                                        leave="transition ease-in duration-75"
                                                        leaveFrom="transform opacity-100 scale-100"
                                                        leaveTo="transform opacity-0 scale-95"
                                                    >
                                                        <Menu.Items style={{marginTop:"-100px"}} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                                            <div className="py-1">
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <Link
                                                                            to="/booking"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Book this device
                                                                        </Link>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            View
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Edit
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Delete
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            QR Code                                                    </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Share                                                    </a>
                                                                    )}
                                                                </Menu.Item>

                                                            </div>
                                                        </Menu.Items>
                                                    </Transition>
                                                </Menu>
                                            </td>



                                        </tr>
                                        

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
              
            </div>

        </div>
    )
}

export default Equipments
