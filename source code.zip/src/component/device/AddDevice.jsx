import React from 'react'
import { NavLink } from "react-router-dom"
const AddDevice = () => {
    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div className='flex items-start justify-center gap-2 pb-2 border-b'>
                <NavLink exact to="/device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        All Equipments
                    </NavLink>
                    <NavLink exact to="/add-dashboard" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Dashboard
                    </NavLink>
                    <NavLink exact to="/device-calibrations" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Equipments Calibrations
                    </NavLink>
                    <NavLink exact to="/add-device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        Add Equipments
                    </NavLink>
                </div>
                <div className=''>
                    <h1 className='text-center text-xl text-pr w-full py-4'>Add Equipments</h1>
                    <div >
                        <form action="#" method="POST">
                            <div className="shadow overflow-hidden sm:rounded-md">
                                <div className="px-4 py-3 bg-white sm:p-6">

                                    <div >
                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                                                Equipments Name*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>
                                        <label htmlFor="first-name" className="block pt-2 text-sm  font-medium text-gray-700">
                                            Equipments Pic*
                                        </label>
                                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">

                                            <div className="space-y-1 text-center">
                                                <svg
                                                    className="mx-auto h-12 w-12 text-gray-400"
                                                    stroke="currentColor"
                                                    fill="none"
                                                    viewBox="0 0 48 48"
                                                    aria-hidden="true"
                                                >
                                                    <path
                                                        d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                                                        strokeWidth={2}
                                                        strokeLinecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                </svg>
                                                <div className="flex text-sm text-gray-600">
                                                    <label
                                                        htmlFor="file-upload"
                                                        className="relative cursor-pointer bg-white rounded-md font-medium text-pr focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                                                    >
                                                        <span>Upload Equipments Pic</span>
                                                        <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                                                    </label>
                                                    <p className="pl-1">PNG, JPG, GIF </p>
                                                </div>

                                            </div>
                                        </div>
                                        <div className=" pt-2">
                                            <label htmlFor="country" className="block text-sm font-medium text-gray-700">
                                                Select Lab
                                            </label>
                                            <select
                                                className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm sm:text-sm"
                                            >
                                                <option>lab1</option>
                                                <option>lab2</option>
                                                <option>lab3</option>
                                            </select>
                                        </div>
                                        <div className='grid grid-cols-1 lg:grid-cols-2 gap-2'>
                                            <div className='mt-2 '>
                                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                    Code*
                                                </label>
                                                <input
                                                    type="text"
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                            <div className='mt-2'>
                                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                    Equipments Type*
                                                </label>
                                                <input
                                                    type="text"
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                        </div>
                                        <div  className='mt-2'>
                                            <label htmlFor="about" className="block text-sm font-medium text-gray-700">
                                                Description*
                                            </label>
                                            <div className="mt-1">
                                                <textarea
                                                    id="about"
                                                    name="about"
                                                    rows={3}
                                                    className="shadow-sm  mt-1 block w-full sm:text-sm border border-gray-300 rounded-md p-2 h-32"
                                                   
                                                />
                                            </div>
                                           
                                        </div>

                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                Project*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>
                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                Model*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>
                                        <div className='grid grid-cols-1 lg:grid-cols-2 gap-2'>
                                            <div className='mt-2 '>
                                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                    Category*
                                                </label>
                                                <input
                                                    type="text"
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                            <div className='mt-2'>
                                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                    Equipments Location*
                                                </label>
                                                <input
                                                    type="text"
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                                />
                                            </div>
                                        </div>
                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                Thing Group*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>
                                        <label htmlFor="first-name" className="block pt-2 text-sm  font-medium text-gray-700">
                                            Upload Certificate
                                        </label>
                                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">

                                            <div className="space-y-1 text-center">
                                                <svg
                                                    className="mx-auto h-12 w-12 text-gray-400"
                                                    stroke="currentColor"
                                                    fill="none"
                                                    viewBox="0 0 48 48"
                                                    aria-hidden="true"
                                                >
                                                    <path
                                                        d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                                                        strokeWidth={2}
                                                        strokeLinecap="round"
                                                        strokeLinejoin="round"
                                                    />
                                                </svg>
                                                <div className="flex text-sm text-gray-600">
                                                    <label
                                                        htmlFor="file-upload"
                                                        className="relative cursor-pointer bg-white rounded-md font-medium text-pr focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                                                    >
                                                        <span>Add Certificate</span>
                                                        <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                                                    </label>
                                                    <p className="pl-1">PNG, JPG, GIF </p>
                                                </div>

                                            </div>
                                        </div>
                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                UserName*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>
                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                User Location*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>

                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                Expertise*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>
                                        <div className='mt-2'>
                                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                                Equipments Parameters*
                                            </label>
                                            <input
                                                type="text"
                                                name="first-name"
                                                id="first-name"
                                                autoComplete="given-name"
                                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                            />
                                        </div>
                                        <fieldset>
                                            <label htmlFor="first-name" className="block pt-3 pb-1 text-sm  font-medium text-gray-700">
                                                Visibility*
                                            </label>
                                            <div className="flex items-center gap-2">
                                                <div className="flex items-center">
                                                    <input
                                                        id="push-everything"
                                                        name="push-notifications"
                                                        type="radio"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300"
                                                    />
                                                    <label htmlFor="push-everything" className="ml-3 block text-sm font-medium text-gray-700">
                                                        Public
                                                    </label>
                                                </div>
                                                <div className="flex items-center">
                                                    <input
                                                        id="push-email"
                                                        name="push-notifications"
                                                        type="radio"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300"
                                                    />
                                                    <label htmlFor="push-email" className="ml-3 block text-sm font-medium text-gray-700">
                                                        Private
                                                    </label>
                                                </div>
                                                <div className="flex items-center">
                                                    <input
                                                        id="push-nothing"
                                                        name="push-notifications"
                                                        type="radio"
                                                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300"
                                                    />
                                                    <label htmlFor="push-nothing" className="ml-3 block text-sm font-medium text-gray-700">
                                                        Internal
                                                    </label>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                                <div className="px-4 py-3 flex items-center gap-2 justify-end bg-gray-50 text-right sm:px-6">
                                    <button
                                        type="submit"
                                        className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-pr"
                                    >
                                        Submit
                                    </button>
                                    <button
                                        type="submit"
                                        className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-pr"
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

        </div>
    )
}

export default AddDevice
