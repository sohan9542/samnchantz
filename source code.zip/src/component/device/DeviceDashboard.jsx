import React, { useState } from 'react'
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    PointElement,
    LineElement,
} from 'chart.js';

import { Line } from 'react-chartjs-2';
import TextField from '@mui/material/TextField';
import { Modal } from "react-bootstrap"
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Bar } from 'react-chartjs-2';
import { FaUserAlt } from "react-icons/fa"
import { BsArrowRightShort } from "react-icons/bs"
import { AiFillCheckCircle } from "react-icons/ai"
import { FaChartLine } from "react-icons/fa"
import { RiPriceTag3Fill } from "react-icons/ri"
import { MdPendingActions } from "react-icons/md"

import { Menu, Transition } from '@headlessui/react'
import { Fragment } from 'react'
import { BsThreeDotsVertical } from "react-icons/bs"
import { AiOutlineUsergroupAdd } from "react-icons/ai"
export const options = {
    responsive: true,
};
ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    PointElement,
    LineElement
);
const labels = ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun', ''];
function classNames(...classes) {
    return classes.filter(Boolean).join(' ')
}
const data = {
    labels,
    datasets: [
        {
            label: 'Parameter 1',
            data: [0, 20, 10, 50, 28, 20, 30, 45, 0],
            backgroundColor: 'rgb(1,34,87)',
        },
        {
            label: 'Parameter 2',
            data: [0, 25, 18, 30, 20, 29, 39, 35,],
            backgroundColor: 'rgb(76, 63, 145)',
        },
        {
            label: 'Parameter 1',
            data: [0, 10, 17, 37, 12, 29, 38, 20, 0],
            backgroundColor: 'rgb(92,122,234)',
        },


    ],
};
const data2 = {
    labels,
    datasets: [
        {
            label: 'Daily usage',
            data: [2000, 8000, 4000, 10000, 9000, 1200, 7200, 9100, 4000, 1000, 0, 0],
            backgroundColor: 'rgb(1,34,87)',
            borderColor: 'rgb(1,34,87)',
        },
        {
            label: 'Average usage',
            data: [6000, 3000, 6000, 7000, 5002, 4008, 3009, 4000, 6000, 0, 0, 2800,],
            backgroundColor: 'rgb(76, 63, 145)',
        },

    ],
};


function ShowParameter(props) {
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >

            <Modal.Body>
                <div>


                    <label htmlFor="about" className="block text-pr text-lg">
                        Add Parameter
                    </label>
                    <div className='grid grid-cols-1 lg:grid-cols-2  items-center'>
                        <TextField id="standard-basic" label="Name" variant="standard" />
                        <FormControl variant="standard" sx={{ m: 1, minWidth: 250 }}>
                            <InputLabel id="demo-simple-select-standard-label">Select Equipments</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"

                                label="Age"
                            >

                                <MenuItem value={10}>Device1</MenuItem>
                                <MenuItem value={20}>Device2</MenuItem>

                            </Select>
                        </FormControl>
                        <TextField id="standard-basic" label="Add Parameters" variant="standard" />

                        <FormControl variant="standard" sx={{ m: 1, minWidth: 250 }}>
                            <InputLabel id="demo-simple-select-standard-label">Select Unit</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"

                                label="Age"
                            >

                                <MenuItem value={10}>Unit</MenuItem>
                                <MenuItem value={20}>Unit</MenuItem>

                            </Select>
                        </FormControl>
                    </div>
                    <button
                        type="submit"
                        className="inline-flex mt-3 text-sm justify-center py-2 px-4 border border-transparent shadow-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                    >
                        Add
                    </button>

                </div>
            </Modal.Body>

        </Modal>
    );
}
function InviteUser(props) {
    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >

            <Modal.Body>
                <div>
                    <label htmlFor="about" className="block text-pr text-lg w-full text-center font-medium">
                        Invite A User
                    </label>
                    <div className='grid grid-cols-1 items-center'>
                        <div className='mt-2'>
                            <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                                Email*
                            </label>
                            <input
                                type="email"
                                name="first-name"
                                id="first-name"
                                autoComplete="given-name"
                                className="mt-1  w-full shadow-sm bg-hr sm:text-sm border p-2 rounded-md"
                            />
                        </div>
                        <div className="py-4 grid grid-cols-2 gap-2">
                            <div className='flex items-center gap-2 justify-center'>  <input type="checkbox" /> <p className='text-pr'>Portal Adminstrator</p> </div>
                            <div className='flex items-center gap-2 justify-center'>  <input type="checkbox" /> <p className='text-pr'>Product Manager</p> </div>

                        </div>
                        <div className='w-full'>
                            <button className='w-full py-2 bg-pr hover:bg-blue-900 text-white rounded-full'>Invite</button>
                        </div>

                    </div>

                </div>
            </Modal.Body>

        </Modal>
    );
}
const DeviceDashboard = () => {
    const [addParameter, setAddParameter] = useState(false)
    const [invite, setInvite] = useState(false)
    const [slab, setSlab] = useState("E")
    return (
        <div className='p-3'>
            <ShowParameter
                show={addParameter}
                onHide={() => setAddParameter(false)} />
            <InviteUser
                show={invite}
                onHide={() => setInvite(false)} />
            <div className='min-h-screen'>
                <div className='bg-white shadow-md w-full pb-3'>

                    <div className='w-full bg-pr p-3 shadow-md '>
                        <div className='grid grid-cols-2 gap-4 lg:gap-0 lg:grid-cols-5 py-3'>
                            <div className='border-r flex justify-center '>
                                <div className='flex items-center text-white text-sm flex-col'>
                                    <div className='flex items-center gap-2'>
                                        <FaUserAlt className="h-4 w-4" /> <p>Active Users</p>
                                    </div>
                                    <h1 className='font-bold font-mono py-2'>1400</h1>
                                    <p className='text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg'>20% Increase</p>
                                </div>
                            </div>
                            <div className='border-r flex justify-center '>
                                <div className='flex items-center text-white text-sm flex-col'>
                                    <div className='flex items-center gap-2'>
                                        <AiFillCheckCircle className="h-4 w-4" /> <p>Parameters</p>
                                    </div>
                                    <h1 className='font-bold py-2'>400</h1>
                                    <p className='text-red-500 border-2 border-red-500 p-2 text-xs rounded-lg'>5% Decrease</p>
                                </div>
                            </div>
                            <div className='border-r flex justify-center '>
                                <div className='flex items-center text-white text-sm flex-col'>
                                    <div className='flex items-center gap-2'>
                                        <FaChartLine className="h-4 w-4" /> <p>Activity</p>
                                    </div>
                                    <h1 className='font-bold py-2'>24000</h1>
                                    <p className='text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg'>10% Increase</p>
                                </div>
                            </div>

                            <div className='border-r flex justify-center '>
                                <div className='flex items-center text-white text-sm flex-col'>
                                    <div className='flex items-center gap-2'>
                                        <RiPriceTag3Fill className="h-4 w-4" /> <p>Daily Usage</p>
                                    </div>
                                    <h1 className='font-bold py-2'>6 Hour</h1>
                                    <p className='text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg'>2% Decrease</p>
                                </div>
                            </div>
                            <div className='flex justify-center '>
                                <div className='flex items-center text-white text-sm flex-col'>
                                    <div className='flex items-center gap-2'>
                                        <MdPendingActions className="h-4 w-4" /> <p>Projects</p>
                                    </div>
                                    <h1 className='font-bold py-2'>80</h1>
                                    <p className='text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg'>20% Increase</p>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className='mt-4 grid grid-cols-1 lg:grid-cols-2 gap-4 px-3'>
                        <div className='bg-white shadow-md p-2'>
                            <div className='flex items-center justify-between'>
                                <h5 className='text-pr pl-3 pb-2'>Activity Overview</h5>
                                <select className='bg-pr rounded-md text-white p-2 border text-xs'>
                                    <option>Daily</option>
                                    <option>Weekly</option>
                                    <option>Monthly</option>
                                    <option>Annual</option>
                                </select>
                            </div>
                            <Line options={options} data={data2} />
                        </div>
                        <div className='bg-white shadow-md p-2'>
                            <div className='pb-2 flex items-center justify-between'>
                                <h5 className='text-pr'>Equipments Parameters</h5>
                                <select className='bg-pr rounded-md text-white p-2 border text-xs'>
                                    <option>All Parameters</option>
                                    <option>Daily</option>
                                    <option>Weekly</option>

                                    <option>Monthly</option>
                                </select>
                                <button onClick={() => setAddParameter(true)} className='text-xs px-2 py-2 bg-pr text-white hover:bg-blue-900 rounded-md'>Add Parameters</button>
                            </div>
                            <Bar options={options} data={data} />
                        </div>
                    </div>
                    <div className='mt-4 grid grid-cols-1 lg:grid-cols-3 divide-x gap-4 px-3'>
                        <div className=' col-span-1 lg:col-span-2 flex pt-4 flex-col overflow-hidden'>
                            <div>
                                <h5 className='text-pr pl-3 pb-2 flex items-center gap-1'>Projects <span className='an'><BsArrowRightShort /></span></h5>
                                <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                                    <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                                        <div className=" border-b pb-2 border-gray-200 sm:rounded-lg">
                                            <table className="min-w-full divide-y divide-gray-200">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Status
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Name
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Description
                                                        </th>
                                                        <th

                                                            scope="col"
                                                            className="px-6 py-3 cursor-pointer text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Owner
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Created
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Action
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody className="bg-white divide-y divide-gray-200">

                                                    <tr>
                                                        <td className="py-4 px-2 whitespace-nowrap flex items-center justify-center">
                                                            <input type="checkbox" className='w-5 h-5 mt-2' name="" id="" />
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>project name</p>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>project description</p>
                                                        </td>

                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>owner name</p>
                                                        </td>
                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>01/01/2020</p>
                                                        </td>

                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <Menu as="div" className="relative inline-block text-left">
                                                                <div>
                                                                    <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                                        <BsThreeDotsVertical className='h-6 w-6' />
                                                                    </Menu.Button>
                                                                </div>

                                                                <Transition
                                                                    as={Fragment}
                                                                    enter="transition ease-out duration-100"
                                                                    enterFrom="transform opacity-0 scale-95"
                                                                    enterTo="transform opacity-100 scale-100"
                                                                    leave="transition ease-in duration-75"
                                                                    leaveFrom="transform opacity-100 scale-100"
                                                                    leaveTo="transform opacity-0 scale-95"
                                                                >
                                                                    <Menu.Items style={{ marginTop: "-50px" }} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white">
                                                                        <div >

                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        View
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Edit
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Share
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Download
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Delete
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Print
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>


                                                                        </div>
                                                                    </Menu.Items>
                                                                </Transition>
                                                            </Menu>
                                                        </td>



                                                    </tr>
                                                    <tr>
                                                        <td className="py-4 px-2 whitespace-nowrap flex items-center justify-center">
                                                            <input type="checkbox" className='w-5 h-5 mt-2' name="" id="" />
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>project name</p>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>project description</p>
                                                        </td>

                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>owner name</p>
                                                        </td>
                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>01/01/2020</p>
                                                        </td>

                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <Menu as="div" className="relative inline-block text-left">
                                                                <div>
                                                                    <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                                        <BsThreeDotsVertical className='h-6 w-6' />
                                                                    </Menu.Button>
                                                                </div>

                                                                <Transition
                                                                    as={Fragment}
                                                                    enter="transition ease-out duration-100"
                                                                    enterFrom="transform opacity-0 scale-95"
                                                                    enterTo="transform opacity-100 scale-100"
                                                                    leave="transition ease-in duration-75"
                                                                    leaveFrom="transform opacity-100 scale-100"
                                                                    leaveTo="transform opacity-0 scale-95"
                                                                >
                                                                    <Menu.Items style={{ marginTop: "-50px" }} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white">
                                                                        <div >

                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        View
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Edit
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Share
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Download
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Delete
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Print
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>


                                                                        </div>
                                                                    </Menu.Items>
                                                                </Transition>
                                                            </Menu>
                                                        </td>



                                                    </tr>
                                                    <tr>
                                                        <td className="py-4 px-2 whitespace-nowrap flex items-center justify-center">
                                                            <input type="checkbox" className='w-5 h-5 mt-2' name="" id="" />
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>project name</p>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>project description</p>
                                                        </td>

                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>owner name</p>
                                                        </td>
                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>01/01/2020</p>
                                                        </td>

                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <Menu as="div" className="relative inline-block text-left">
                                                                <div>
                                                                    <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                                        <BsThreeDotsVertical className='h-6 w-6' />
                                                                    </Menu.Button>
                                                                </div>

                                                                <Transition
                                                                    as={Fragment}
                                                                    enter="transition ease-out duration-100"
                                                                    enterFrom="transform opacity-0 scale-95"
                                                                    enterTo="transform opacity-100 scale-100"
                                                                    leave="transition ease-in duration-75"
                                                                    leaveFrom="transform opacity-100 scale-100"
                                                                    leaveTo="transform opacity-0 scale-95"
                                                                >
                                                                    <Menu.Items style={{ marginTop: "-50px" }} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white">
                                                                        <div >

                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        View
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Edit
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Share
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Download
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Delete
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Print
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>


                                                                        </div>
                                                                    </Menu.Items>
                                                                </Transition>
                                                            </Menu>
                                                        </td>



                                                    </tr>



                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='pt-5'>
                                <h5 className='text-pr pl-3 pb-2 flex items-center gap-1'>Alerts  <span className='an'><BsArrowRightShort /></span></h5>
                                <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                                    <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                                        <div className=" border-b pb-2 border-gray-200 sm:rounded-lg">
                                            <table className="min-w-full divide-y divide-gray-200">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Threats
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Description
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Connection
                                                        </th>
                                                        <th

                                                            scope="col"
                                                            className="px-6 py-3 cursor-pointer text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Protocol
                                                        </th>
                                                        <th

                                                            scope="col"
                                                            className="px-6 py-3 cursor-pointer text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Severty
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Time
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Duration
                                                        </th>
                                                        <th
                                                            scope="col"
                                                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                        >
                                                            Action
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody className="bg-white divide-y divide-gray-200">
                                                    <tr>

                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>Threat name</p>
                                                        </td>
                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <p>description</p>
                                                        </td>

                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>connecton</p>
                                                        </td>
                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>protocol name</p>
                                                        </td>
                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>Critical</p>
                                                        </td>
                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>01/01/2020 11:14pm</p>
                                                        </td>
                                                        <td className="py-4 px-6 whitespace-nowrap">
                                                            <p>2 hours</p>
                                                        </td>

                                                        <td className="px-6 py-4 whitespace-nowrap">
                                                            <Menu as="div" className="relative inline-block text-left">
                                                                <div>
                                                                    <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                                        <BsThreeDotsVertical className='h-6 w-6' />
                                                                    </Menu.Button>
                                                                </div>

                                                                <Transition
                                                                    as={Fragment}
                                                                    enter="transition ease-out duration-100"
                                                                    enterFrom="transform opacity-0 scale-95"
                                                                    enterTo="transform opacity-100 scale-100"
                                                                    leave="transition ease-in duration-75"
                                                                    leaveFrom="transform opacity-100 scale-100"
                                                                    leaveTo="transform opacity-0 scale-95"
                                                                >
                                                                    <Menu.Items style={{ marginTop: "-50px" }} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white">
                                                                        <div >

                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Take Action
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>
                                                                            <Menu.Item>
                                                                                {({ active }) => (
                                                                                    <a
                                                                                        href="#"
                                                                                        className={classNames(
                                                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                            'block px-4 py-2 text-sm'
                                                                                        )}
                                                                                    >
                                                                                        Delete
                                                                                    </a>
                                                                                )}
                                                                            </Menu.Item>


                                                                        </div>
                                                                    </Menu.Items>
                                                                </Transition>
                                                            </Menu>
                                                        </td>



                                                    </tr>


                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='p-3'>
                            <h4 className=' text-pr text-center w-full pb-3'>Location</h4>
                            <select className='bg-pr rounded-md text-white p-2 border text-xs'>
                                <option>Lab XX</option>
                                <option>Lab1</option>
                                <option>Lab2</option>
                            </select>
                            <div className='py-2 overflow-hidden rounded-md'>
                                <img src="https://cdn.labmanager.com/assets/articleNo/2352/iImg/5015/11bf19af-3e36-4fe0-991c-0ec7e91f9f5e-mar18-ls-future-640x360.jpg" alt="" />
                            </div>
                            <h6 className='text-pr border-t  pt-3 pb-1'>Lab</h6>
                            <div className="grid grid-cols-1 bg-hr shadow-md w-full mt-2">
                                <option onClick={()=>setSlab("E")} className={slab === "E" ? 'p-2 cursor-pointer text-white bg-pr text-sm': 'p-2 cursor-pointer text-pr bg-hr text-sm'}>Entrence</option>
                                <option onClick={()=>setSlab("B")} className={slab === "B" ? 'p-2 cursor-pointer text-white bg-pr text-sm': 'p-2 cursor-pointer text-pr bg-hr text-sm'}>Backyard</option>
                                <option onClick={()=>setSlab("L")} className={slab === "L" ? 'p-2 cursor-pointer text-white bg-pr text-sm': 'p-2 cursor-pointer text-pr bg-hr text-sm'}>Living Room</option>
                                <option onClick={()=>setSlab("H")} className={slab === "H" ? 'p-2 cursor-pointer text-white bg-pr text-sm': 'p-2 cursor-pointer text-pr bg-hr text-sm'}>Haliway</option>
                                <option onClick={()=>setSlab("BE")} className={slab === "BE" ? 'p-2 cursor-pointer text-white bg-pr text-sm': 'p-2 cursor-pointer text-pr bg-hr text-sm'}>Bedroom</option>
                                <option onClick={()=>setSlab("F")} className={slab === "F" ? 'p-2 cursor-pointer text-white bg-pr text-sm': 'p-2 cursor-pointer text-pr bg-hr text-sm'}>Fontdoor</option>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='mt-4  w-full'>
                    <h3 className=' text-2xl font-semibold pb-3 font-semibold text-pr'>Users</h3>
                    <div className='w-full pb-2 flex items-center justify-between'>

                        <p className=' font-medium text-pr'>Managers</p>
                        <button onClick={() => setInvite(true)} className="px-2 py-2 bg-pr text-white flex items-center rounded-md hover:bg-blue-900"><AiOutlineUsergroupAdd className='w-5 h-5 ' /> Invite</button>
                    </div>
                    <div className='w-full'>
                        <div className=' grid grid-cols-1 lg:grid-cols-5 gap-3'>
                            <div className="h-72 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-full p-3'>
                                    <div className='w-20 h-20 rounded-full overflow-hidden'>
                                        <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-72 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-full p-3'>
                                    <div className='w-20 h-20 rounded-full overflow-hidden'>
                                        <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-72 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-full p-3'>
                                    <div className='w-20 h-20 rounded-full overflow-hidden'>
                                        <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-72 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-full p-3'>
                                    <div className='w-20 h-20 rounded-full overflow-hidden'>
                                        <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-72 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-full p-3'>
                                    <div className='w-20 h-20 rounded-full overflow-hidden'>
                                        <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>





                        </div>
                    </div>
                </div>
                <div className='mt-4  w-full'>
                    <div className='w-full pb-2 flex items-center'>
                        <h5 className=' font-medium text-pr'>Teams</h5>
                    </div>
                    <div className='w-full'>
                        <div className=' grid grid-cols-1 lg:grid-cols-5 gap-3'>
                            <div className="h-60 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-60 p-3'>
                                    <div className='flex items-center'>
                                        <div className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>


                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-60 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-60 p-3'>
                                    <div className='flex items-center'>
                                        <div className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>


                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-60 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-60 p-3'>
                                    <div className='flex items-center'>
                                        <div className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>


                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-60 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-60 p-3'>
                                    <div className='flex items-center'>
                                        <div className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>


                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div className="h-60 rounded-md bg-white shadow-md">
                                <div className='flex items-center justify-center flex-col h-60 p-3'>
                                    <div className='flex items-center'>
                                        <div className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg" alt="" />
                                        </div>
                                        <div style={{ marginLeft: "-15px" }} className='w-12 h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg" alt="" />
                                        </div>


                                    </div>
                                    <div className='text-center pt-2'>
                                        <h5 className='text-pr font-medium pt-2'>John Parker</h5>
                                        <p className='text-gray-500 font-semibold text-sm'>UX, Designer</p>
                                    </div>
                                    <div className='flex items-center gap-1 justify-around pt-3'>
                                        <div className='bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl'>
                                            UI
                                        </div>
                                        <div className=' w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl'>
                                            UX
                                        </div>
                                        <div className='bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl'>
                                            Photoshop
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-1 pt-2 justify-center'>
                                        <div className='bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl'>
                                            +7
                                        </div>

                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default DeviceDashboard
