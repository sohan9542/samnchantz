
import { NavLink } from 'react-router-dom'

import React, { useState } from 'react'
import TextField from '@mui/material/TextField';
import { Modal } from "react-bootstrap"
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { FiEdit } from "react-icons/fi"
import { AiOutlineDelete } from "react-icons/ai"
import { BsArrowRightShort } from "react-icons/bs"
function MyVerticallyCenteredModal(props) {
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >

            <Modal.Body>
                <div>


                    <label htmlFor="about" className="block text-pr text-lg">
                        Create Calibration
                    </label>
                    <div className='grid grid-cols-1 gap-2 lg:grid-cols-3  items-center'>

                        <FormControl variant="standard" >
                            <InputLabel id="demo-simple-select-standard-label">Select Hospital</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"

                                label="Age"
                            >

                                <MenuItem value={10}>Hosipital1</MenuItem>
                                <MenuItem value={20}>Hosipital2</MenuItem>

                            </Select>
                        </FormControl>

                        <FormControl variant="standard">
                            <InputLabel id="demo-simple-select-standard-label">Select Department</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"


                                label="Age"
                            >

                                <MenuItem value={10}>Department1</MenuItem>
                                <MenuItem value={20}>Department2</MenuItem>

                            </Select>
                        </FormControl>

                        <FormControl variant="standard" >
                            <InputLabel id="demo-simple-select-standard-label">Unique Id</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"

                                label="Age"
                            >

                                <MenuItem value={10}>1</MenuItem>
                                <MenuItem value={20}>2</MenuItem>

                            </Select>
                        </FormControl>
                        <TextField id="standard-basic" label="Equipments Name" variant="standard" />
                        <TextField id="standard-basic" label="Serial Number" variant="standard" />
                        <TextField id="standard-basic" label="Company" variant="standard" />
                        <TextField id="standard-basic" label="Model" variant="standard" />
                        <TextField id="standard-basic" label="Calibration Date" variant="standard" />
                        <TextField id="standard-basic" label="Due Date" variant="standard" />
                        <TextField id="standard-basic" label="Cirtification Number" variant="standard" />
                        <TextField id="standard-basic" label="Company" variant="standard" />
                        <TextField id="standard-basic" label="Contact Person" variant="standard" />
                        <TextField id="standard-basic" label="Contact Person Mobile No." variant="standard" />
                        <TextField id="standard-basic" label="Engineer Mobile No." variant="standard" />
                        <TextField id="standard-basic" label="Traceability Certificate Number" variant="standard" />
                    </div>
                    <button
                        type="submit"
                        className="inline-flex mt-3 text-sm justify-center py-2 px-4 border border-transparent shadow-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                    >
                        Submit
                    </button>

                </div>
            </Modal.Body>

        </Modal>
    );
}

const Calibration = () => {

    const [setWopen, setSetWopen] = useState(false)

    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div className='flex items-start justify-center gap-2 pb-2 border-b'>
                <NavLink exact to="/device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        All Equipments
                    </NavLink>
                    <NavLink exact to="/add-dashboard" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Dashboard
                    </NavLink>
                    <NavLink exact to="/device-calibrations" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Equipments Calibrations
                    </NavLink>
                    <NavLink exact to="/add-device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        Add Equipments
                    </NavLink>
                </div>
                <div className='p-3'>
                    <h1 className='text-center text-xl text-pr w-full pb-4'>Calibrations</h1>


                    <MyVerticallyCenteredModal
                        show={setWopen}
                        onHide={() => setSetWopen(false)}
                    />
                    <div className="flex items-center justify-between gap-3 w-full">
                        <div >
                            <h1 className='text-xl text-pr w-full flex items-center gap-1'>All Calibrations <BsArrowRightShort /></h1>
                        </div>
                        <button
                            onClick={() => setSetWopen(true)}
                            type="submit"
                            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                        >
                            Add New
                        </button>
                    </div>
                    <div className="flex pt-4 flex-col overflow-hidden">
                        <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead className="bg-gray-50">
                                            <tr>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    
                                                    Equipments Id
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Equipments Name
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    User
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Calibration Date
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Due Date
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Cirtificate No
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Company
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Contact Person
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Actions
                                                </th>

                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">

                                            <tr >

                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">1</div>

                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">Equipments name</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">user name</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">01/01/1010</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">01/01/1010</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">0000</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">Company name</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">Person name</div>
                                                </td>
                                                <td className="px-6 py-4 flex items-center justify-center gap-2">
                                                    <div className="bg-pr text-white flex items-center justify-center px-2 py-2 cursor-pointer rounded-md hover:bg-blue-800"><FiEdit /></div>
                                                    <div className="bg-pr text-white flex items-center justify-center px-2 py-2 cursor-pointer rounded-md hover:bg-blue-800"><AiOutlineDelete /></div>
                                                </td>

                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='mt-5'>
                        <h1 className='text-xl text-pr w-full pb-4 flex items-center gap-1'>Calibration Reminders <BsArrowRightShort /></h1>
                    </div>
                    <div className="flex pt-4 flex-col overflow-hidden">
                        <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead className="bg-gray-50">
                                            <tr>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Equipments Id
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Equipments Name
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    User
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Calibration Date
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Due Date (days remaining)
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Added by
                                                </th>

                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Contact Person
                                                </th>


                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">

                                            <tr >

                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">1</div>

                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">Equipments name</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">user name</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">01/01/1010</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">0 days</div>
                                                </td>

                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">name</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">Person name</div>
                                                </td>


                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                    <div className='mt-5'>
                        <h1 className='text-xl text-pr w-full pb-4 flex items-center gap-1'>Calibration Stickers  <BsArrowRightShort /></h1>
                    </div>
                    <div className="flex pt-4 flex-col overflow-hidden">
                        <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead className="bg-gray-50">
                                            <tr>
                                              
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Lab
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Unique Id
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Equipments Id
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Maintenance Date 
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Maintenance Due Date
                                                </th>

                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Calibration Due Date
                                                </th>
                                                <th
                                                    scope="col"
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    Action
                                                </th>


                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">

                                            <tr >

                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">lab name</div>

                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">unique id</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">device name</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">01/01/1010</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">01/01/1010</div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm text-gray-900">01/01/1010</div>
                                                </td>

                                                <td className="px-6 py-4 whitespace-nowrap">
                                                <button className='px-2 py-2 bg-pr uppercase text-white rounded-md text-sm'>A single Stickers</button>
                                                </td>
                                            


                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='mt-5'>
                        <h1 className='text-xl text-pr w-full pb-2'>Filter Stickers</h1>
                    </div>
                    <div className=" items-center gap-4 grid grid-cols-1 lg:grid-cols-3 w-full pb-4 border-b">

                        <FormControl variant="standard">
                            <InputLabel id="demo-simple-select-standard-label">Select Lab</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"

                                label="Age"
                            >

                                <MenuItem value={10}>lab1</MenuItem>
                                <MenuItem value={20}>lab2</MenuItem>

                            </Select>
                        </FormControl>
                        <FormControl variant="standard">
                            <InputLabel id="demo-simple-select-standard-label">Equipments ID</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"

                                label="Age"
                            >

                                <MenuItem value={10}>1</MenuItem>
                                <MenuItem value={20}>2</MenuItem>

                            </Select>
                            
                        </FormControl>
                        <div className="flex items-center gap-2">
                            <button className='px-2 py-2 bg-pr text-white rounded-md text-sm'>Submit</button>
                            <button className='px-2 py-2 bg-pr text-white rounded-md text-sm'>Generate Stickers</button>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    )
}

export default Calibration
