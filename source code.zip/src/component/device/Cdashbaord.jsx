import React, { useState } from 'react'
import { NavLink } from "react-router-dom"
import TextField from '@mui/material/TextField';
import { Modal } from "react-bootstrap"
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Menu, Transition } from '@headlessui/react'
import { Fragment } from 'react'
import {Link} from "react-router-dom"
import {BsThreeDotsVertical} from "react-icons/bs"
import { BsArrowRightShort } from "react-icons/bs"
function MyVerticallyCenteredModal(props) {
    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >

            <Modal.Body>
                <div>


                    <label htmlFor="about" className="block  text-pr text-lg">
                        Add Dashboard
                    </label>
                    <TextField id="standard-basic" label="Name"  sx={{ width: 400 }} variant="standard" />
                    <div className='mt-2'>
                        <label htmlFor="about" className="block text-base text-gray-500">
                            Description
                        </label>
                        <div className="mt-1">
                            <textarea
                                id="about"
                                name="about"
                                rows={3}
                                className="shadow-sm  mt-1 block w-full sm:text-sm border border-gray-300 rounded-md p-2 h-32"

                            />
                        </div>
                        <button
                            type="submit"
                            className="inline-flex mt-3 text-sm justify-center py-2 px-4 border border-transparent shadow-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                        >
                            Add
                        </button>
                    </div>

                </div>
            </Modal.Body>

        </Modal>
    );
}
function MyVerticallyCenteredModal2(props) {
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >

            <Modal.Body>
                <div>


                    <label htmlFor="about" className="block text-pr text-lg">
                        Add Parameter
                    </label>
                    <div className='grid grid-cols-1 lg:grid-cols-2  items-center'>
                        <TextField id="standard-basic" label="Name" variant="standard" />
                        <FormControl variant="standard" sx={{ m: 1, minWidth: 250 }}>
                            <InputLabel id="demo-simple-select-standard-label">Select Equipments</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"
                              
                                label="Age"
                            >

                                <MenuItem value={10}>Device1</MenuItem>
                                <MenuItem value={20}>Device2</MenuItem>

                            </Select>
                        </FormControl>

                        <TextField id="standard-basic" label="Add Parameter" variant="standard" />

                        <FormControl variant="standard" sx={{ m: 1, minWidth: 250 }}>
                            <InputLabel id="demo-simple-select-standard-label">Select Unit</InputLabel>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"
                               
                                label="Age"
                            >

                                <MenuItem value={10}>Unit</MenuItem>
                                <MenuItem value={20}>Unit</MenuItem>

                            </Select>
                        </FormControl>
                    </div>
                    <button
                        type="submit"
                        className="inline-flex mt-3 text-sm justify-center py-2 px-4 border border-transparent shadow-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                    >
                        Add
                    </button>

                </div>
            </Modal.Body>

        </Modal>
    );
}
const Cdashbaord = () => {
    const [setWopen, setSetWopen] = useState(false)
    const [modalShow, setModalShow] = React.useState(false);
    function classNames(...classes) {
        return classes.filter(Boolean).join(' ')
    }
    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div className='flex items-start justify-center gap-2 pb-2 border-b'>
                <NavLink exact to="/device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        All Equipments
                    </NavLink>
                    <NavLink exact to="/add-dashboard" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Dashboard
                    </NavLink>
                    <NavLink exact to="/device-calibrations" activeClassName='bg-pr pr' className='border py-1 px-2 text-sr hover:text-sr text-sm font-medium cursor-pointer '>
                        Equipments Calibrations
                    </NavLink>
                    <NavLink exact to="/add-device" activeClassName='bg-pr pr' className='border py-1 px-2 text-sm text-sr hover:text-sr font-medium cursor-pointer '>
                        Add Equipments
                    </NavLink>
                </div>
                <div className='p-3'>
                    <h1 className='text-center text-xl text-pr w-full pb-4'>Add Dashboard</h1>
                    <div className="flex w-full items-center gap-8 flex-wrap">
                        <TextField id="standard-basic" label="Dashboard Name"  variant="standard" />

                        <TextField
                            id="date"
                            label="Start Date"
                            type="date"

                            sx={{ width: 220 }}
                            InputLabelProps={{
                                shrink: true,
                            }}
                        />
                        <TextField
                            id="date"
                            label="End Date"
                            type="date"

                            sx={{ width: 220 }}
                            InputLabelProps={{
                                shrink: true,
                            }}
                        />
                    </div>


                    <MyVerticallyCenteredModal
                        show={modalShow}
                        onHide={() => setModalShow(false)}
                    />
                    <MyVerticallyCenteredModal2
                        show={setWopen}
                        onHide={() => setSetWopen(false)}
                    />
                    <div className="flex items-center justify-between w-full">
                        <div className="py-4 flex items-center  gap-2 bg-gray-50">
                            <button
                                type="submit"
                                className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                            >
                                Clear
                            </button>
                            <button
                                type="submit"
                                className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                            >
                                Search
                            </button>
                        </div>
                        <button
                            onClick={() => setModalShow(true)}
                            type="submit"
                            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-pr hover:bg-blue-900"
                        >
                            Add Dashboard
                        </button>
                    </div>
                    <div className="flex pt-4 flex-col overflow-hidden">
                    <h1 className='text-center text-xl text-pr flex items-center gap-1 justify-center w-full pb-4'>All Equipments  <BsArrowRightShort /></h1>
                    <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className=" border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Dashboard Id
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Name
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Equipments Id
                                            </th>
                                            <th
                                            onClick={()=>setSetWopen(true)}
                                                scope="col"
                                                className="px-6 py-3 cursor-pointer text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Parameters
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Created At
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Action
                                            </th>
                                            

                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">

                                        <tr >

                                
                                            <td className="py-4 px-2 whitespace-nowrap">
                                            <p>20 data to display</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>test</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>xxxxxx</p>
                                            </td>
                                            
                                            <td className="py-4 px-6 whitespace-nowrap">
                                                <p>4</p>
                                            </td>
                                            <td className="py-4 px-6 whitespace-nowrap">
                                                <p>01/01/2020</p>
                                            </td>
                                          
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <Menu as="div" className="relative inline-block text-left">
                                                    <div>
                                                        <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                            <BsThreeDotsVertical className='h-6 w-6' />
                                                        </Menu.Button>
                                                    </div>

                                                    <Transition
                                                        as={Fragment}
                                                        enter="transition ease-out duration-100"
                                                        enterFrom="transform opacity-0 scale-95"
                                                        enterTo="transform opacity-100 scale-100"
                                                        leave="transition ease-in duration-75"
                                                        leaveFrom="transform opacity-100 scale-100"
                                                        leaveTo="transform opacity-0 scale-95"
                                                    >
                                                        <Menu.Items style={{ marginTop:"-100px"}} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white">
                                                            <div >
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <Link to="/device-dashboard/1"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            View
                                                                        </Link>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Edit
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Delete
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Share                                                    </a>
                                                                    )}
                                                                </Menu.Item>

                                                            </div>
                                                        </Menu.Items>
                                                    </Transition>
                                                </Menu>
                                            </td>



                                        </tr>
                                    

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>

        </div>
    )
}

export default Cdashbaord
