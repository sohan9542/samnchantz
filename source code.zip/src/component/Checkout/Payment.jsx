import React, { useState } from 'react'
import { BsCreditCard2Back } from "react-icons/bs"
import { RiPaypalLine } from "react-icons/ri"
import { AiOutlineBank } from "react-icons/ai"
const Payment = () => {
    const [card, setCard] = useState("C")
    return (
        <div className='p-3'>
            <h3 className='text-pr text-center w-full py-3'>Checkout</h3>
            <div className='grid grid-cols-1 lg:grid-cols-3 gap-4'>
                <div className='col-span-1 lg:col-span-2  w-full '>
                    <div className='bg-white p-3 rounded-md w-full shadow-md'>
                        <h5 className='text-pr pb-2 w-full border-b font-medium'>Billing Information</h5>
                        <div className='grid grid-cols-1 lg:grid-cols-2 gap-2'>
                            <div className='mt-2 '>
                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                    First Name <span className='text-red-500'>*</span>
                                </label>
                                <input
                                    type="text"
                                    name="first-name"
                                    id="first-name"
                                    placeholder='First Name'
                                    autoComplete="given-name"
                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                />
                            </div>
                            <div className='mt-2'>
                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                    Last Name <span className='text-red-500'>*</span>
                                </label>
                                <input
                                    type="text"
                                    name="first-name"
                                    placeholder='Last Name'
                                    id="first-name"
                                    autoComplete="given-name"
                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                />
                            </div>
                        </div>
                        <div className='mt-2 '>
                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                Company Name <span className='text-red-500'>*</span>
                            </label>
                            <input
                                type="text"
                                name="first-name"
                                id="first-name"
                                placeholder='Company'
                                autoComplete="given-name"
                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                            />
                        </div>
                        <div className='mt-2 '>
                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                Email Address <span className='text-red-500'>*</span>
                            </label>
                            <input
                                type="text"
                                name="first-name"
                                id="first-name"
                                placeholder='Email'
                                autoComplete="given-name"
                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                            />
                        </div>
                        <div className='mt-2 '>
                            <label htmlFor="first-name" className="block text-sm pb-1  font-medium text-gray-700">
                                Country <span className='text-red-500 '>*</span>
                            </label>
                            <select className='p-2 border rounded-md w-full text-sm'>
                                <option>United States</option>
                                <option>Country1</option>
                                <option>Country1</option>
                            </select>
                        </div>
                        <div className='mt-2 '>
                            <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                Address <span className='text-red-500'>*</span>
                            </label>
                            <input
                                type="text"
                                name="first-name"
                                id="first-name"
                                placeholder='Home Address'
                                autoComplete="given-name"
                                className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                            />
                        </div>
                        <div className='grid grid-cols-1 lg:grid-cols-2 gap-2'>
                            <div className='mt-2 '>
                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                    City <span className='text-red-500'>*</span>
                                </label>
                                <input
                                    type="text"
                                    name="first-name"
                                    id="first-name"
                                    placeholder='City'
                                    autoComplete="given-name"
                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                />
                            </div>
                            <div className='mt-2'>
                                <label htmlFor="first-name" className="block text-sm  font-medium text-gray-700">
                                    Postal Code <span className='text-red-500'>*</span>
                                </label>
                                <input
                                    type="text"
                                    name="first-name"
                                    placeholder='Zip Code'
                                    id="first-name"
                                    autoComplete="given-name"
                                    className="mt-1  w-full shadow-sm sm:text-sm border p-2 rounded-md"
                                />
                            </div>
                            <div className='mt-2'>
                                <button className='text-white bg-pr text-sm hover:bg-blue-900 px-2 py-2 rounded-md'>Save & Deliver Here</button>
                            </div>
                        </div>
                    </div>
                    <div className='mt-4 bg-white w-full p-3 shadow-md rounded-md'>
                        <h5 className='text-pr pb-2 w-full border-b font-medium'>Payment Information</h5>
                        <div className='grid grid-cols-3 divide-x'>
                            <div onClick={() => setCard("C")} className={card === "C" ? 'flex items-center gap-2 p-3 rounded-sm bg-pr text-white cursor-pointer' : 'flex items-center gap-2 p-3 text-gray-500 cursor-pointer'}>
                                <BsCreditCard2Back /> <p>Credit Card</p>
                            </div>

                            <div onClick={() => setCard("P")} className={card === "P" ? 'flex items-center gap-2 p-3 rounded-sm bg-pr text-white cursor-pointer' : 'flex items-center gap-2 p-3 text-gray-500 cursor-pointer'}>
                                <RiPaypalLine /> <p>PayPal</p>
                            </div>

                            <div onClick={() => setCard("B")} className={card === "B" ? 'flex items-center gap-2 p-3 rounded-sm bg-pr text-white cursor-pointer' : 'flex items-center gap-2 p-3 text-gray-500 cursor-pointer'}>
                                <AiOutlineBank /> <p>Bank Transfer</p>
                            </div>

                        </div>
                        <div className='py-4'>
                            <p className="text-gray-500 text-sm pb-2">Bank account details</p>
                            <div className='pb-3'>
                                <p className=" text-pr font-medium uppercase">Bank : </p>
                                <p className="text-gray-500 text-sm uppercase">the union bank</p>
                            </div>
                            <div className='pb-3'>
                                <p className=" text-pr font-medium capitalize">Account Number : </p>
                                <p className="text-gray-500 text-sm uppercase">543345435654652346</p>
                            </div>
                            <div className='pb-1'>
                                <p className=" text-pr font-medium uppercase">IBAN : </p>
                                <p className="text-gray-500 text-sm uppercase">5433454</p>
                            </div>
                            <p className="text-gray-500 text-xs w-full pt-2 border-t">Note: Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta inventore animi dignissimos neque cupiditate odit quibusdam repudiandae sequi, ab alias corporis, quam nemo asperiores rem.</p>
                        </div>
                    </div>
                </div>
                <div>
                    <div className='p-3 bg-white shadow-md rounded-md'>
                        <h5 className='text-pr pb-2 w-full border-b font-medium'>Address</h5>
                        <div className='py-3'>
                            <h6 className='font-medium text-pr'>Persy Kewshum</h6>
                            <p className="text-gray-500 text-xs uppercase py-2">4321 Bingamon Branch Road</p>
                            <p className="text-gray-500 text-xs uppercase py-2">Chicago, II-60606</p>
                            <p className="text-gray-500 text-xs uppercase py-2">UTC-5 Eastern Standerd Time(EST)</p>
                            <p className="text-gray-500 text-xs uppercase py-2">+125 254 3564</p>
                            <div className='mt-2'>
                                <button className='text-white bg-pr text-sm hover:bg-blue-900 px-2 py-2 rounded-md'>Deliver to this address</button>
                            </div>
                        </div>
                    </div>
                    <div className='p-3 bg-white shadow-md mt-3 rounded-md'>
                        <h5 className='text-pr pb-2 w-full border-b font-medium'>Your Order</h5>
                        <div className='py-3'>
                            <div className='flex items-center gap-2'>
                                <div className='h-24 w-28'>
                                    <img style={{ width: "100%", height: "100%", objectFit: "Cover" }} src="https://image.made-in-china.com/2f0j00bdftAvyWfHkR/12-1-CH-Health-ECG-Monitor-Patient-Hospital-Patient-Monitor-Yk-8000c.jpg" alt="" />
                                </div>
                                <div>
                                    <p className='font-bold text-pr text-sm'>CH Health ECG Monitor Hospital Patient Monitor</p>
                                </div>
                            </div>
                        </div>
                        <div className='mt-4 pt-2 border-t w-full'>
                            <div className='flex items-center justify-around w-full'>
                                <div className='flex items-center justify-center flex-col gap-2'>
                                    <p className='text-gray-500'>Sub Total</p>
                                    <p className='text-gray-500'>Discount</p>
                                    <p className='text-gray-500'>Shipping</p>
                                    <p className='text-gray-500'>Total</p>
                                </div>
                                <div className='flex items-center justify-center flex-col gap-2'>
                                    <p className='text-pr font-bold'>$4320</p>
                                    <p className='text-pr font-bold'>5%</p>
                                    <p className='text-pr font-bold'>Free</p>
                                    <p className='text-pr font-bold'>$3200</p>
                                </div>
                              
                            </div>
                            <div className='mt-4 pt-2 border-t w-full flex items-center justify-end'>
                                    <button className='text-white bg-pr text-sm hover:bg-blue-900 px-2 py-2 rounded-md'>Place Order</button>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Payment
