import React from 'react'
import { BsThreeDotsVertical } from "react-icons/bs"
import { Menu, Transition } from '@headlessui/react'
import { Fragment } from 'react'
import { BsArrowRightShort } from "react-icons/bs"
const Vlist = () => {
    function classNames(...classes) {
        return classes.filter(Boolean).join(' ')
    }
    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div className="flex pt-4 flex-col overflow-hidden">
                    <h1 className='text-center text-xl text-pr w-full pb-4 flex items-center gap-1 justify-center'>Vendors Name <BsArrowRightShort/></h1>
                    <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className="shadow overflow-hidden border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Cusomer
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Email
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Contracts
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Title
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Country
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Payment Type
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                              Price
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Date
                                            </th>
                                         
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Action
                                            </th>
                                        

                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">

                                        <tr>

                                          
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>vendor name</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>vendor@vendor.com</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>contract</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>title</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>country</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>Monthly</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>$00</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>01/01/1010</p>
                                            </td>
                                      
                                    
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <Menu as="div" className="relative inline-block text-left">
                                                    <div>
                                                        <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                            <BsThreeDotsVertical className='h-6 w-6' />
                                                        </Menu.Button>
                                                    </div>

                                                    <Transition
                                                        as={Fragment}
                                                        enter="transition ease-out duration-100"
                                                        enterFrom="transform opacity-0 scale-95"
                                                        enterTo="transform opacity-100 scale-100"
                                                        leave="transition ease-in duration-75"
                                                        leaveFrom="transform opacity-100 scale-100"
                                                        leaveTo="transform opacity-0 scale-95"
                                                    >
                                                        <Menu.Items style={{ marginTop:"-120px"}} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white">
                                                            <div className="py-1">
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Details
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Edit
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Delete
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Share                                                    </a>
                                                                    )}
                                                                </Menu.Item>

                                                            </div>
                                                        </Menu.Items>
                                                    </Transition>
                                                </Menu>
                                            </td>



                                        </tr>
                                      

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    )
}

export default Vlist
