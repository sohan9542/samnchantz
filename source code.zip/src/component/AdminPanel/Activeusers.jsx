import React from 'react'
import { BsThreeDotsVertical } from "react-icons/bs"
import { AiOutlineUsergroupAdd } from "react-icons/ai"
import { Menu, Transition } from '@headlessui/react'
import { Fragment } from 'react'
import {Modal} from "react-bootstrap"
import { NavLink } from 'react-router-dom'
import {BsArrowRightShort} from "react-icons/bs"
function InviteUser(props) {
    return (
        <Modal
            {...props}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >

            <Modal.Body>
                <div>
                    <label htmlFor="about" className="block text-pr text-lg w-full text-center font-medium">
                        Add Users
                    </label>
                    <div className='grid grid-cols-1 items-center'>
                        <div className='mt-2'>
                            <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                                Email*
                            </label>
                            <input
                                type="email"
                                name="first-name"
                                id="first-name"
                                autoComplete="given-name"
                                className="mt-1  w-full shadow-sm bg-hr sm:text-sm border p-2 rounded-md"
                            />
                        </div>
                        <div className="py-4 grid grid-cols-2 gap-2">
                            <div className='flex items-center gap-2 justify-center'>  <input type="checkbox" /> <p className='text-pr'>Admin</p> </div>
                            <div className='flex items-center gap-2 justify-center'>  <input type="checkbox" /> <p className='text-pr'>Manager</p> </div>

                        </div>
                        <div className='w-full'>
                            <button className='w-full py-2 bg-pr hover:bg-blue-900 text-white rounded-full'>Add</button>
                        </div>

                    </div>

                </div>
            </Modal.Body>

        </Modal>
    );
}
const ActiveUser = () => {
    function classNames(...classes) {
        return classes.filter(Boolean).join(' ')
    }
    const [checked, setChecked] = React.useState(true);

    const handleChange = (event) => {
        setChecked(event.target.checked);
    };
    const [invite, setInvite] = React.useState(false)
    return (
        <div className='p-3 '>
             <InviteUser
                show={invite}
                onHide={() => setInvite(false)} />
            <div className='bg-white shadow-md w-full p-3 min-h-screen'>
                <div className='flex items-start justify-center gap-2 pb-2 border-b'>
                    <NavLink exact to="/manage-roles" activeClassName='bg-pr pr' className='border p-1 text-xs font-medium cursor-pointer hover:text-sr text-sr'>
                        Manage Roles
                    </NavLink>
                    <NavLink exact to="/manage-users" activeClassName='bg-pr pr' className='border p-1 text-xs font-medium cursor-pointer hover:text-sr text-sr'>
                    Manage Users
                    </NavLink>
                   

                </div>
                <div className="flex pt-4 flex-col overflow-hidden">
                    <h1 className='text-center text-xl text-pr w-full pb-4 flex items-center gap-1 justify-center'>Active Users <BsArrowRightShort/></h1>
                   <div className='flex w-full justify-end'>
                   <button onClick={() => setInvite(true)} className="px-2 py-2 bg-pr text-white flex items-center rounded-md hover:bg-blue-900"><AiOutlineUsergroupAdd className='w-5 h-5 ' /> Add users</button>
                   </div>
                    <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className="shadow border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Image
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Name
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Email
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Created On
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Status
                                            </th>
                                           

                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Action
                                            </th>

                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">

                                        <tr >

                                            <td className="whitespace-nowrap">
                                                <div className='p-2'>
                                                    <img style={{ width: "100px", height: "100px", objectFit: "cover" }} src="https://t3.ftcdn.net/jpg/02/58/89/90/360_F_258899001_68CalsKTRk6PZQgWH9JhR4heBlncCko9.jpg" alt="" />

                                                </div>

                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>name</p>
                                            </td>
                                            <td className="py-4 whitespace-nowrap">
                                                <p>user@user.com</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>Dec, 8, 2012</p>
                                            </td>
                                            <td className="py-4 whitespace-nowrap">
                                            
                                             <p className='p-2 ml-4 bg-hr rounded-md text-xs text-pr w-16 text-center'>Active</p>
                                             
                                            </td>
                                           
                                            
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <Menu as="div" className="relative inline-block text-left">
                                                    <div>
                                                        <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                            <BsThreeDotsVertical className='h-6 w-6' />
                                                        </Menu.Button>
                                                    </div>

                                                    <Transition
                                                        as={Fragment}
                                                        enter="transition ease-out duration-100"
                                                        enterFrom="transform opacity-0 scale-95"
                                                        enterTo="transform opacity-100 scale-100"
                                                        leave="transition ease-in duration-75"
                                                        leaveFrom="transform opacity-100 scale-100"
                                                        leaveTo="transform opacity-0 scale-95"
                                                    >
                                                        <Menu.Items style={{ marginTop: "-100px" }} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                                            <div className="py-1">
                                                               
                                                               
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Edit
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Delete
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                               
                                                              

                                                            </div>
                                                        </Menu.Items>
                                                    </Transition>
                                                </Menu>
                                            </td>



                                        </tr>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex mt-12 flex-col overflow-hidden">
                    <h1 className='text-center text-xl text-pr w-full pb-4 flex items-center justify-center gap-1'>Pending Users <BsArrowRightShort/></h1>
 
                    <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className="shadow border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Image
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Name
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Email
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Created On
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Status
                                            </th>
                                           

                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Action
                                            </th>

                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">

                                        <tr >

                                            <td className="whitespace-nowrap">
                                                <div className='p-2'>
                                                    <img style={{ width: "100px", height: "100px", objectFit: "cover" }} src="https://t3.ftcdn.net/jpg/02/58/89/90/360_F_258899001_68CalsKTRk6PZQgWH9JhR4heBlncCko9.jpg" alt="" />

                                                </div>

                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>name</p>
                                            </td>
                                            <td className="py-4 whitespace-nowrap">
                                                <p>user@user.com</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>Dec, 8, 2012</p>
                                            </td>
                                            <td className="py-4 whitespace-nowrap">
                                            
                                             <p className='p-2 ml-4 bg-hr rounded-md text-xs text-pr w-16 text-center'>Pending</p>
                                             
                                            </td>
                                           
                                            
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <Menu as="div" className="relative inline-block text-left">
                                                    <div>
                                                        <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                            <BsThreeDotsVertical className='h-6 w-6' />
                                                        </Menu.Button>
                                                    </div>

                                                    <Transition
                                                        as={Fragment}
                                                        enter="transition ease-out duration-100"
                                                        enterFrom="transform opacity-0 scale-95"
                                                        enterTo="transform opacity-100 scale-100"
                                                        leave="transition ease-in duration-75"
                                                        leaveFrom="transform opacity-100 scale-100"
                                                        leaveTo="transform opacity-0 scale-95"
                                                    >
                                                        <Menu.Items style={{ marginTop: "-100px" }} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                                            <div className="py-1">
                                                               
                                                               
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Approve
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Decline
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                               
                                                              

                                                            </div>
                                                        </Menu.Items>
                                                    </Transition>
                                                </Menu>
                                            </td>



                                        </tr>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default ActiveUser
