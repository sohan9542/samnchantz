import React, { useState } from 'react'
import { BsThreeDots } from "react-icons/bs"
import { BiSearch } from "react-icons/bi"
import { RiChatSmileLine } from "react-icons/ri"
import { MdOutlineCall, MdPermContactCalendar } from "react-icons/md"
import { IoIosNotificationsOutline, IoIosArrowDown } from "react-icons/io"
import { NavLink } from 'react-router-dom'
import { Menu, Transition } from '@headlessui/react'
import { Fragment } from 'react'
import { BsThreeDotsVertical } from "react-icons/bs"
const Chatbox = () => {
    const [active, setActive] = useState("C")
    function classNames(...classes) {
        return classes.filter(Boolean).join(' ')
    }
    return (
        <div className='p-3'>
            <div style={{ height: "780px" }} className='bg-white shadow-md w-full flex items-start overflow-hidden'>
                <div>
                    <div className=' w-20 lg:w-72 h-full lg:block p-2'>
                        <div className='flex items-center justify-between flex-col lg:flex-row border-b pb-2'>
                            <div className=' flex items-center gap-2'>
                                <div className='relative'>
                                    <div className='w-12 h-12 rounded-full overflow-hidden'>
                                        <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://t3.ftcdn.net/jpg/02/22/85/16/360_F_222851624_jfoMGbJxwRi5AWGdPgXKSABMnzCQo9RN.jpg" alt="" />
                                    </div>
                                    <div className='w-3 h-3 bg-green-400 rounded-full absolute z-30 bottom-2 right-0'>

                                    </div>
                                </div>
                                <div className=' hidden lg:block'>
                                    <p className=' font-medium'>Rachel Zane</p>
                                </div>
                            </div>
                            <div>
                                <BsThreeDots className='w-6 h-6 cursor-pointer text-pr' />
                            </div>
                        </div>
                        <div className=' pt-2 hidden lg:block'>
                            <div className='flex items-center justify-between w-full border'>
                                <div className='w-full'>
                                    <input type="text" placeholder='People, groups & messages' className='w-100 text-sm px-1 outline-none border-none h-full' />
                                </div>
                                <div className='border-l p-1 cursor-pointer hover:bg-hr'>
                                    <BiSearch className='text-pr h-5 w-5' />
                                </div>
                            </div>
                        </div>
                        <div className='w-full pt-3 grid grid-cols-2 lg:flex items-center justify-around  pb-2 border-b'>
                            <div onClick={() => setActive("C")} className={active === "C" ? "flex items-center cursor-pointer flex-col text-pr" : "flex items-center cursor-pointer flex-col text-sr"}>
                                <RiChatSmileLine className='h-5 w-5' />
                                <p className='text-sm hidden lg:block'>Chats</p>
                            </div>
                            <div onClick={() => setActive("V")} className={active === "V" ? "flex items-center cursor-pointer flex-col text-pr" : "flex items-center cursor-pointer flex-col text-sr"}>
                                <MdOutlineCall className='h-5 w-5' />
                                <p className='text-sm hidden lg:block'>Calls</p>
                            </div>
                            <div onClick={() => setActive("T")} className={active === "T" ? "flex items-center cursor-pointer flex-col text-pr" : "flex items-center cursor-pointer flex-col text-sr"}>
                                <MdPermContactCalendar className='h-5 w-5' />
                                <p className='text-sm hidden lg:block'>Contact</p>
                            </div>
                            <div onClick={() => setActive("S")} className={active === "S" ? "flex items-center cursor-pointer flex-col text-pr" : "flex items-center cursor-pointer flex-col text-sr"}>
                                <IoIosNotificationsOutline className='h-5 w-5' />
                                <p className='text-sm hidden lg:block'>Notification</p>
                            </div>
                        </div>
                        <div className='pt-3'>
                            <p className="text-sm text-pr font-medium uppercase lg:flex items-start gap-1 cursor-pointer hidden">Recent Chats <IoIosArrowDown /></p>
                        </div>
                        <div style={{ height: "570px" }} className='w-full gap-1 grid grid-cols-1 pt-3 overflow-y-scroll'>
                            <NavLink to="/chatbox/0" activeClassName='bg-hr tc' className="p-0 lg:p-3 pt-1 px-1 border-b rounded-md h-12 lg:h-16 mr-1">
                                <div className='flex items-center gap-0 lg:gap-3'>
                                    <div className='relative'>
                                        <div className=' h-10 w-10 lg:w-12 lg:h-12 rounded-full overflow-hidden'>
                                            <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://wallpaperaccess.com/full/945410.jpg" alt="" />
                                        </div>
                                        <div className='w-3 h-3 bg-green-400 rounded-full absolute z-30 bottom-1 right-0'>

                                        </div>
                                    </div>
                                    <div className='hidden lg:block pl-3'>
                                        <div>
                                            <p className='font-medium text-gray-900'>Luis Garget</p>
                                            <p className='text-gray-500 text-sm'>This is message</p>
                                        </div>
                                    </div>
                                </div>
                            </NavLink>
                        </div>
                    </div>
                </div>
                <div className='border w-full h-full p-3'>
                    <div className='flex items-center justify-between pb-3 border-b'>
                        <div className='flex items-center gap-2'>
                            <div className='relative'>
                                <div className='w-12 h-12 rounded-full overflow-hidden'>
                                    <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://wallpaperaccess.com/full/945410.jpg" alt="" />
                                </div>
                            </div>

                            <div>
                                <p className='font-medium text-gray-900'>Luis Garget</p>
                                <div className='relative'>
                                    <div className='w-3 h-3 bg-green-400 rounded-full absolute z-30 top-1 left-0'>

                                    </div>
                                    <div className='flex items-center'>
                                        <p className='text-gray-500 text-sm pl-4'>Active Now</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div>
                            <Menu as="div" className="relative inline-block text-left">
                                <div>
                                    <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                        <BsThreeDotsVertical className='h-6 w-6' />
                                    </Menu.Button>
                                </div>

                                <Transition
                                    as={Fragment}
                                    enter="transition ease-out duration-100"
                                    enterFrom="transform opacity-0 scale-95"
                                    enterTo="transform opacity-100 scale-100"
                                    leave="transition ease-in duration-75"
                                    leaveFrom="transform opacity-100 scale-100"
                                    leaveTo="transform opacity-0 scale-95"
                                >
                                    <Menu.Items className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                        <div className="py-1">
                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(
                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                            'block px-4 py-2 text-sm'
                                                        )}
                                                    >
                                                        Block
                                                    </a>
                                                )}
                                            </Menu.Item>

                                            <Menu.Item>
                                                {({ active }) => (
                                                    <a
                                                        href="#"
                                                        className={classNames(
                                                            active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                            'block px-4 py-2 text-sm'
                                                        )}
                                                    >
                                                        Delete
                                                    </a>
                                                )}
                                            </Menu.Item>



                                        </div>
                                    </Menu.Items>
                                </Transition>
                            </Menu>
                        </div>
                    </div>
                    <div style={{ height: "520px" }} className='w-full overflow-y-scroll px-2 py-4'>
                        <div className='flex items-center gap-2'>
                            <div className='w-10 h-10 hidden lg:block rounded-full overflow-hidden'>
                                <img style={{ height: "100%", width: "100%", objectFit: "cover" }} src="https://wallpaperaccess.com/full/945410.jpg" alt="" />
                            </div>
                            <div className="flex flex-col">
                                <p className='text-sr text-xs pb-1'>Harvey, 2:35PM</p>
                                <div className='flex flex-col justify-start w-auto max-w-sm lg:max-w-md bg-hr p-2 rounded-md'>
                                    <p className='text-pr text-sm font-medium'>Hey Rachel Zane! How is the template is looking?</p>
                                </div>
                            </div>
                        </div>
                        <div className='flex justify-end mt-3'>
                            <div className="flex flex-col">
                                <p className='text-sr text-xs pb-1'>Me, 2:36PM</p>
                                <div className='flex flex-col justify-start w-auto max-w-md bg-blue-200 p-2 rounded-md'>
                                    <p className='text-pr text-sm font-medium'>The Template is looking awesome, Specially the chatbox is great. I just love it. What about you?</p>
                                </div>
                            </div>
                        </div>
                    

                    </div>
                    <div className=' w-full h-52 flex flex-col gap-2 mt-2 pb-5'>
                        <textarea name="" id="" cols="30" rows="5" className='text-pr text-sm w-full border-none outline-none bg-hr p-2'>

                        </textarea>
                        <div className='flex items-center justify-end'>
                            <button className='text-white bg-pr px-2 py-2 hover:bg-blue-900 rounded-md'>Send</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Chatbox
