import React from "react";
import { FiCheck } from "react-icons/fi";
import {

  AiOutlineCalendar,

} from "react-icons/ai";
import { FaRegEdit } from "react-icons/fa";

import { IoBulbSharp } from "react-icons/io5";

import { GiHistogram } from "react-icons/gi";

import UsersInfo from "./Main Dashboard Component/UsersInfo";
import Availablility from "./Main Dashboard Component/Availablility";
import Inbox from "./Main Dashboard Component/Inbox";
import Contracts from "./Main Dashboard Component/Contracts";
import OutgoingProject from "./Main Dashboard Component/OutgoingProject";
import DevicesStatus from "./Main Dashboard Component/DevicesStatus";
import Properties from "./Main Dashboard Component/Properties";
import RecentAdded from "./Main Dashboard Component/RecentAdded";
import UserManager from "./Main Dashboard Component/UserManager";
import EventCalender from "./Main Dashboard Component/EventCalender";



const Dashboard = () => {

  return (
    <div className="p-3 min-h-screen">
    
     <UsersInfo/>
    <Availablility/>
     <Inbox/>
     <Contracts/>
     <OutgoingProject/>
      <DevicesStatus/>
      <Properties/>
      <RecentAdded/>
      <UserManager/>
      <EventCalender/>
    </div>
  );
};

export default Dashboard;
