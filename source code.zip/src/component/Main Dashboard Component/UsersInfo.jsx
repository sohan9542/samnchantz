import React from "react";
import { FaUserAlt } from "react-icons/fa";
import {
  AiFillCheckCircle,

} from "react-icons/ai";
import { FaChartLine, FaCriticalRole, FaRegEdit } from "react-icons/fa";
import { RiPriceTag3Fill } from "react-icons/ri";
import { ImLab } from "react-icons/im";

import { MdPendingActions } from "react-icons/md";

const UsersInfo = () => {
  return (
    <div className="w-full bg-pr p-3 shadow-md ">
        <div className="grid grid-cols-2 gap-2 lg:gap-0 lg:grid-cols-7 py-3">
          <div className="border-r flex justify-center ">
            <div className="flex items-center justify-center text-white text-sm flex-col">
              <div className="flex items-center gap-2">
                <FaUserAlt className="h-4 w-4" /> <p>All Users</p>
              </div>
              <h4 className="font-bold font-mono py-2">1400</h4>
              <p className="text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg">
                2.7% Increase
              </p>
            </div>
          </div>
          <div className="border-r flex justify-center ">
            <div className="flex items-center text-white text-sm flex-col">
              <div className="flex items-center gap-2">
                <FaCriticalRole className="h-4 w-4" /> <p>All Roles</p>
              </div>
              <h4 className="font-bold font-mono py-2">1400</h4>
              <p className="text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg">
                20% Increase
              </p>
            </div>
          </div>
          <div className="border-r flex justify-center ">
            <div className="flex items-center text-white text-sm flex-col">
              <div className="flex items-center gap-2">
                <ImLab className="h-4 w-4" /> <p>My Labs</p>
              </div>
              <h4 className="font-bold font-mono py-2">1400</h4>
              <p className="text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg">
                20% Increase
              </p>
            </div>
          </div>
          <div className="border-r flex justify-center ">
            <div className="flex items-center text-white text-sm flex-col">
              <div className="flex items-center gap-2">
                <AiFillCheckCircle className="h-4 w-4" /> <p>Projects</p>
              </div>
              <h4 className="font-bold py-2">400</h4>
              <p className="text-red-500 border-2 border-red-500 p-2 text-xs rounded-lg">
                5% Decrease
              </p>
            </div>
          </div>
          <div className="border-r flex justify-center ">
            <div className="flex items-center text-white text-sm flex-col">
              <div className="flex items-center gap-2">
                <FaChartLine className="h-4 w-4" /> <p>Contracts</p>
              </div>
              <h4 className="font-bold py-2">24000</h4>
              <p className="text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg">
                10% Increase
              </p>
            </div>
          </div>
          <div className="flex border-r justify-center ">
            <div className="flex items-center text-white text-sm flex-col">
              <div className="flex items-center gap-2">
                <MdPendingActions className="h-4 w-4" /> <p>Equipment</p>
              </div>
              <h4 className="font-bold py-2">80</h4>
              <p className="text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg">
                20% Increase
              </p>
            </div>
          </div>
          <div className=" flex justify-center ">
            <div className="flex items-center text-white text-sm flex-col">
              <div className="flex items-center gap-2">
                <RiPriceTag3Fill className="h-4 w-4" /> <p>Sales</p>
              </div>
              <h4 className="font-bold py-2">6 Hour</h4>
              <p className="text-green-500 border-2 border-green-500 p-2 text-xs rounded-lg">
                2% Decrease
              </p>
            </div>
          </div>
        </div>
      </div>
  )
}

export default UsersInfo