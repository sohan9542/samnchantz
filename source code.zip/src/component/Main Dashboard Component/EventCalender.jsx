import React from "react";
import { Calendar, momentLocalizer, Views } from "react-big-calendar";
import moment from "moment";
import * as dates from "./dates";
import events from "./events";

const localizer = momentLocalizer(moment);

let allViews = Object.keys(Views).map((k) => Views[k]);

const ColoredDateCellWrapper = ({ children }) =>
  React.cloneElement(React.Children.only(children), {
    style: {
      backgroundColor: "#012257",
    },
  });

const EventCalender = () => {
  return (
    <div className="mt-3 w-full bg-white shadow-md p-3">
      <h2 className="text-pr text-2xl font-semibold w-full pb-2 border-b">Event Calender</h2>
      <div className="w-full pt-4">
        <div className="w-full">
          <div className=" w-full grid grid-cols-1 lg:grid-cols-4 gap-2">
            <div className="w-full ">
              <button className=" bg-purple-600 w-full text-white rounded-md py-2 px-2 text-sm hover:bg-purple-800">
                Add New Event
              </button>
              <p className="text-sm text-gray-400 pt-2">Drag and drop your event or click in the calender</p>
              <form className="w-full mt-8 flex flex-col gap-2">
                <div className=" bg-purple-300 w-full flex items-center gap-2  cursor-pointer text-purple-600 font-semibold rounded-md py-2 px-2 text-sm hover:bg-purple-200 ">
                  <input type="radio" value={0} name="family" id="family" />
                  <label htmlFor="family" className="w-full cursor-pointer"> Family Vacation</label>
                </div>
                <div className=" bg-yellow-300 w-full text-yellow-600 flex items-center gap-2 cursor-pointer font-semibold rounded-md py-2 px-2 text-sm hover:bg-yellow-200">
                  <input type="radio" value={1} name="family" id="meeting" />
                  <label htmlFor="meeting" className="w-full cursor-pointer">Meeting In office</label>
                </div>
                <div className=" bg-pink-300 w-full text-pink-600 flex items-center gap-2 cursor-pointer  font-semibold rounded-md py-2 px-2 text-sm hover:bg-pink-200">
                  <input type="radio" value={2} name="family" id="client" />
                  <label htmlFor="client" className="w-full cursor-pointer"> Client Call</label>
                </div>
                <div className=" bg-green-300 w-full text-green-600 flex items-center gap-2 cursor-pointer  font-semibold rounded-md py-2 px-2 text-sm hover:bg-green-200">
                  <input type="radio" value={3} name="family" id="interview" />
                  <label htmlFor="interview" className="w-full cursor-pointer">Interview</label>
                </div>
              </form>
            </div>
            <div className="w-full lg:col-span-3">
              <Calendar
                localizer={localizer}
                events={events}
                startAccessor="start"
                step={60}
                endAccessor="end"
                components={{
                  timeSlotWrapper: ColoredDateCellWrapper,
                }}
                style={{ height: 500 }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventCalender;
