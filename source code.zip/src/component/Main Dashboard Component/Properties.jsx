import React from "react";
import { AiFillStar } from "react-icons/ai";
const Properties = () => {
  const [active, setActive] = React.useState(1);
  return (
    <div className="w-full grid mt-3 grid-cols-1 lg:grid-cols-3 gap-2">
      <div className=" col-span-2 bg-white shadow-md p-3">
        <div className="flex items-center justify-between">
          <h2 className="text-pr text-2xl font-semibold">Properties Overview</h2>
          <div className="flex items-center divide-x">
            <button
              onClick={() => setActive(1)}
              className={
                active === 1
                  ? "bg-purple-700 px-2 py-1  text-white text-sm"
                  : " px-2 py-1  text-gray-600 border text-sm"
              }
            >
              Public
            </button>
            <button
              onClick={() => setActive(2)}
              className={
                active === 2
                ? "bg-purple-700 px-2 py-1  text-white text-sm"
                : " px-2 py-1  text-gray-600 border  text-sm"
              }
            >
              Internal
            </button>
            <button
              onClick={() => setActive(3)}
              className={
                active === 3
                ? "bg-purple-700 px-2 py-1  text-white text-sm"
                : " px-2 py-1  text-gray-600 border  text-sm"
              }
            >
              Private
            </button>
          
          </div>
        </div>
        <div className="flex items-center justify-end w-full pt-2">
        <button
              onClick={() => setActive(4)}
              className={
                active === 4
                ? "bg-purple-700 px-3 py-1  text-white text-sm"
                : " px-3 py-1  text-gray-600 border  text-sm"
              }
            >
              Sell
            </button>
            <button
              onClick={() => setActive(5)}
              className={
                active === 5
                ? "bg-purple-700 px-3 py-1  text-white text-sm"
                : " px-3 py-1  text-gray-600 border  text-sm"
              }
            >
              Rent
            </button>
        </div>
        <div className="mt-3 w-full flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-12 ">
                <img
                  src="https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm text-gray-900">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                </p>
                <p className="text-xs text-gray-500">
                  Lorem ipsum dolor sit amet consectetur
                </p>
              </div>
            </div>
            <div>
              <button className="w-20 hover:bg-blue-700 bg-pr text-white px-2 py-1 rounded-md text-xs">
                Read More
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-12 ">
                <img
                  src="https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm text-gray-900">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                </p>
                <p className="text-xs text-gray-500">
                  Lorem ipsum dolor sit amet consectetur
                </p>
              </div>
            </div>
            <div>
              <button className="w-20 hover:bg-blue-700 bg-pr text-white px-2 py-1 rounded-md text-xs">
                Read More
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-12 ">
                <img
                  src="https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm text-gray-900">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                </p>
                <p className="text-xs text-gray-500">
                  Lorem ipsum dolor sit amet consectetur
                </p>
              </div>
            </div>
            <div>
              <button className="w-20 hover:bg-blue-700 bg-pr text-white px-2 py-1 rounded-md text-xs">
                Read More
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-12 ">
                <img
                  src="https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm text-gray-900">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                </p>
                <p className="text-xs text-gray-500">
                  Lorem ipsum dolor sit amet consectetur
                </p>
              </div>
            </div>
            <div>
              <button className="w-20 hover:bg-blue-700 bg-pr text-white px-2 py-1 rounded-md text-xs">
                Read More
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-12 ">
                <img
                  src="https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm text-gray-900">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                </p>
                <p className="text-xs text-gray-500">
                  Lorem ipsum dolor sit amet consectetur
                </p>
              </div>
            </div>
            <div>
              <button className="w-20 hover:bg-blue-700 bg-pr text-white px-2 py-1 rounded-md text-xs">
                Read More
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="bg-white w-full shadow-md p-3">
        <h2 className="text-pr text-2xl font-semibold w-full pb-2 border-b">Experts List</h2>
        <div className="w-full flex flex-col gap-2 pt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div style={{ width: "40px" }}>
                <img
                  src="https://static.toiimg.com/photo/83890830/83890830.jpg?v=3"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  Expert Name
                </p>
                <p className="text-xs text-gray-500">Expert job title</p>
              </div>
            </div>
            <div>
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  20 Job Done
                </p>
                <p className="text-xs text-gray-400 flex items-center">
                  <AiFillStar className=" text-yellow-500 w-4 h-4" /> (4.5) 9
                  reviews
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div style={{ width: "40px" }}>
                <img
                  src="https://static.toiimg.com/photo/83890830/83890830.jpg?v=3"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  Expert Name
                </p>
                <p className="text-xs text-gray-500">Expert job title</p>
              </div>
            </div>
            <div>
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  20 Job Done
                </p>
                <p className="text-xs text-gray-400 flex items-center">
                  <AiFillStar className=" text-yellow-500 w-4 h-4" /> (4.5) 9
                  reviews
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div style={{ width: "40px" }}>
                <img
                  src="https://static.toiimg.com/photo/83890830/83890830.jpg?v=3"
                  style={{ width: "100%", heigth: "100%", objectFit: "cover" }}
                  alt=""
                />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  Expert Name
                </p>
                <p className="text-xs text-gray-500">Expert job title</p>
              </div>
            </div>
            <div>
              <div>
                <p className="text-sm font-semibold text-gray-900">
                  20 Job Done
                </p>
                <p className="text-xs text-gray-400 flex items-center">
                  <AiFillStar className=" text-yellow-500 w-4 h-4" /> (4.5) 9
                  reviews
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Properties;
