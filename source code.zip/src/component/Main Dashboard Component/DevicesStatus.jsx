import React from "react";

import { AiFillCiCircle } from "react-icons/ai";

import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
const data = [
  { name: "Group A", value: 400 },
  { name: "Group B", value: 300 },
  { name: "Group C", value: 300 },
  { name: "Group D", value: 200 },
];

const RADIAN = Math.PI / 180;

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];
const renderCustomizedLabel = ({
  cx,
  cy,
  midAngle,
  innerRadius,
  outerRadius,
  percent,
  index,
}) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);

  return (
    <text
      x={x}
      y={y}
      fill="white"
      textAnchor={x > cx ? "start" : "end"}
      dominantBaseline="central"
    >
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

const DevicesStatus = () => {
  return (
    <div className=" mt-3 w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
      <div
        className="bg-white rounded-lg shadow-md w-full h-full flex flex-col py-2"
        style={{ height: "420px" }}
      >
        <h2 className="text-pr text-2xl font-semibold pl-3">Equipment Status</h2>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart width={400} height={400}>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[index % COLORS.length]}
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="flex flex-col gap-1 px-3 pb-4">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 rounded-full bg-blue-500"></div>
              <p>Equipment in use</p>
            </div>
            <div>
              <p className="px-2 py-1 rounded-xl text-xs bg-gray-200">33%</p>
            </div>
          </div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              <p>Equipment in idle</p>
            </div>
            <div>
              <p className="px-2 py-1 rounded-xl text-xs bg-gray-200">25%</p>
            </div>
          </div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
              <p>Equipment at risk</p>
            </div>
            <div>
              <p className="px-2 py-1 rounded-xl text-xs bg-gray-200">25%</p>
            </div>
          </div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 rounded-full bg-yellow-700"></div>
              <p>Others</p>
            </div>
            <div>
              <p className="px-2 py-1 rounded-xl text-xs bg-gray-200">17%</p>
            </div>
          </div>
        </div>
      </div>
      <div
        className="bg-white shadow-md w-full h-full rounded-lg flex flex-col  py-2 px-3"
        style={{ height: "420px" }}
      >
        <h2 className="text-pr text-2xl font-semibold">Maintenance & Calibrations</h2>

        <div
          style={{ height: "300px" }}
          className="flex flex-col overflow-y-scroll my-2 border-t border-b w-full"
        >
          <div className="flex flex-col items-center pb-4 border-l mt-10">
            <div className="flex items-center w-full gap-2 justify-between text-sm">
              <div className="w-2 h-2 rounded-full bg-pink-500"></div>
              <div className="flex w-full items-center justify-between">
                <div className="flex flex-col">
                  <p>People Shared a Post</p>
                  <p className="text-gray-500 text-xs">
                    It Was a Awesome Work!
                  </p>
                </div>
                <p className=" text-xs">8:30 PM</p>
              </div>
            </div>
            <div className="mt-2 flex items-center ">
              <div>
                <img
                  src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                  className="rounded-full border-2 border-purple-500"
                  style={{
                    objectFit: "cover",
                    width: "30px",
                    height: "30px",
                  }}
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                  className="rounded-full  border-2 border-green-500 "
                  style={{
                    objectFit: "cover",
                    width: "30px",
                    height: "30px",
                  }}
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                  className="rounded-full  border-2 border-blue-500 "
                  style={{
                    objectFit: "cover",
                    width: "30px",
                    height: "30px",
                  }}
                  alt=""
                />
              </div>
            </div>
          </div>
          <div className="flex flex-col items-center  border-l pb-4">
            <div className="flex items-center w-full gap-2 justify-between text-sm">
              <div className="w-2 h-2 rounded-full bg-purple-500"></div>
              <div className="flex w-full items-center justify-between">
                <div className="flex flex-col">
                  <p>People Shared a Post</p>
                  <p className="text-gray-500 text-xs">
                    It Was a Awesome Work!
                  </p>
                </div>
                <p className=" text-xs">8:30 PM</p>
              </div>
            </div>
            <div className="mt-2 flex items-center ">
              <div>
                <img
                  src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                  className="rounded-full border-2 border-purple-500"
                  style={{
                    objectFit: "cover",
                    width: "30px",
                    height: "30px",
                  }}
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                  className="rounded-full  border-2 border-pink-500 "
                  style={{
                    objectFit: "cover",
                    width: "30px",
                    height: "30px",
                  }}
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                  className="rounded-full  border-2 border-green-500 "
                  style={{
                    objectFit: "cover",
                    width: "30px",
                    height: "30px",
                  }}
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between ">
          <button className="px-2 py-1 rounded-md bg-pr hover:bg-blue-800 text-white w-20">
            More
          </button>
          <button className="px-2 py-1 rounded-md bg-pr hover:bg-blue-800 text-white w-40">
            Add New Task
          </button>
        </div>
      </div>
      <div
        className="bg-white shadow-md w-full h-full flex flex-col overflow-y-scroll rounded-lg py-2 px-3"
        style={{ height: "420px" }}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-pr text-2xl font-semibold">Support Ticket</h2>
          <p className=" cursor-pointer bg-blue-100 px-2 hover:bg-blue-200 py-1 text-xs rounded-xl">
            View all
          </p>
        </div>

        <div
          style={{ height: "400px" }}
          className="flex flex-col gap-3 items-center pb-4 mt-3"
        >
          <div className="flex items-center w-full justify-between text-sm">
            <div className="flex w-full items-center gap-2">
              <AiFillCiCircle className="w-7 h-7 text-pr" />
              <div className="flex flex-col">
                <p style={{fontSize:"10px"}} className=" text-gray-400">Webstar HTML5</p>
                <p style={{fontSize:"12px"}} className=" font-semibold text-gray-900 text-sm">I get and Error "No Direct Access Allowed!" When I Enter Purchase </p>
                <p style={{fontSize:"10px"}} className="text-gray-500">Created By samual woods | Sunday March 19, 2020</p>
              </div>
            </div>
          </div>
          <div className="flex items-center w-full justify-between text-sm">
            <div className="flex w-full items-center gap-2">
              <AiFillCiCircle className="w-7 h-7 text-pr" />
              <div className="flex flex-col">
                <p style={{fontSize:"10px"}} className=" text-gray-400">Webstar HTML5</p>
                <p style={{fontSize:"12px"}} className=" font-semibold text-gray-900 text-sm">I get and Error "No Direct Access Allowed!" When I Enter Purchase </p>
                <p style={{fontSize:"10px"}} className="text-gray-500">Created By samual woods | Sunday March 19, 2020</p>
              </div>
            </div>
          </div>
          <div className="flex items-center w-full justify-between text-sm">
            <div className="flex w-full items-center gap-2">
              <AiFillCiCircle className="w-7 h-7 text-pr" />
              <div className="flex flex-col">
                <p style={{fontSize:"10px"}} className=" text-gray-400">Webstar HTML5</p>
                <p style={{fontSize:"12px"}} className=" font-semibold text-gray-900 text-sm">I get and Error "No Direct Access Allowed!" When I Enter Purchase </p>
                <p style={{fontSize:"10px"}} className="text-gray-500">Created By samual woods | Sunday March 19, 2020</p>
              </div>
            </div>
          </div>
        

      

        
        </div>
      </div>
    </div>
  );
};

export default DevicesStatus;
