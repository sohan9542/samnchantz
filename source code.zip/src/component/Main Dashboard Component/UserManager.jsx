import React, { useState } from "react";
import { AiOutlineUsergroupAdd } from "react-icons/ai";
import { Modal } from "react-bootstrap";
function InviteUser(props) {
  return (
    <Modal
      {...props}
      size="md"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Body>
        <div>
          <div className="grid grid-cols-1 items-center">
            <label
              htmlFor="about"
              className="block text-pr text-lg w-full text-center font-medium"
            >
              Invite A User
            </label>
            <div className="grid grid-cols-1 items-center">
              <div className="mt-2">
                <label
                  htmlFor="first-name"
                  className="block text-sm font-medium text-gray-700"
                >
                  Email*
                </label>
                <input
                  type="email"
                  name="first-name"
                  id="first-name"
                  autoComplete="given-name"
                  className="mt-1  w-full shadow-sm bg-hr sm:text-sm border p-2 rounded-md"
                />
              </div>
              <div className="py-4 grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2 justify-center">
                  {" "}
                  <input type="checkbox" />{" "}
                  <p className="text-pr">Portal Adminstrator</p>{" "}
                </div>
                <div className="flex items-center gap-2 justify-center">
                  {" "}
                  <input type="checkbox" />{" "}
                  <p className="text-pr">Product Manager</p>{" "}
                </div>
              </div>
              <div className="w-full">
                <button className="w-full py-2 bg-pr hover:bg-blue-900 text-white rounded-full">
                  Invite
                </button>
              </div>
            </div>
            <div className="p-3 mt-2 w-full bg-blue-50">
              <p className=" font-semibold text-pr pb-3">Invited</p>
              <div className="flex items-center gap-2">
                <div className="w-16 h-16 rounded-md">
                  <img
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                    }}
                    src="https://m.media-amazon.com/images/I/81IYW6A3ZiL._SX425_.jpg"
                    alt=""
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="text-sm text-gray-600">Dragon Design</p>
                  <p className="text-xs text-gray-400">dragon@gmail.com</p>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-3">
                <div className="w-16 h-16 rounded-md">
                  <img
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                    }}
                    src="https://m.media-amazon.com/images/I/81IYW6A3ZiL._SX425_.jpg"
                    alt=""
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="text-sm text-gray-600">Dragon Design</p>
                  <p className="text-xs text-gray-400">dragon@gmail.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}
const UserManager = () => {
  const [invite, setInvite] = useState(false);
  return (
    <div>
      <InviteUser show={invite} onHide={() => setInvite(false)} />
      <div className="mt-4  w-full">
        <h3 className=" text-2xl font-semibold pb-3 font-semibold text-pr">
          Users
        </h3>
        <div className="w-full pb-2 flex items-center justify-between">
          <p className=" font-medium text-pr">Managers</p>
          <button
            onClick={() => setInvite(true)}
            className="px-2 py-2 bg-pr text-white flex items-center rounded-md hover:bg-blue-900"
          >
            <AiOutlineUsergroupAdd className="w-5 h-5 " /> Invite
          </button>
        </div>
        <div className="w-full">
          <div className=" grid grid-cols-1 lg:grid-cols-5 gap-3">
            <div className="h-72 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-full p-3">
                <div className="w-20 h-20 rounded-full overflow-hidden">
                  <img
                    style={{
                      height: "100%",
                      width: "100%",
                      objectFit: "cover",
                    }}
                    src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                    alt=""
                  />
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-72 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-full p-3">
                <div className="w-20 h-20 rounded-full overflow-hidden">
                  <img
                    style={{
                      height: "100%",
                      width: "100%",
                      objectFit: "cover",
                    }}
                    src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                    alt=""
                  />
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-72 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-full p-3">
                <div className="w-20 h-20 rounded-full overflow-hidden">
                  <img
                    style={{
                      height: "100%",
                      width: "100%",
                      objectFit: "cover",
                    }}
                    src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                    alt=""
                  />
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-72 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-full p-3">
                <div className="w-20 h-20 rounded-full overflow-hidden">
                  <img
                    style={{
                      height: "100%",
                      width: "100%",
                      objectFit: "cover",
                    }}
                    src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                    alt=""
                  />
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-72 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-full p-3">
                <div className="w-20 h-20 rounded-full overflow-hidden">
                  <img
                    style={{
                      height: "100%",
                      width: "100%",
                      objectFit: "cover",
                    }}
                    src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                    alt=""
                  />
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-4  w-full">
        <div className="w-full pb-2 flex items-center">
          <h5 className=" font-medium text-pr">Teams</h5>
        </div>
        <div className="w-full">
          <div className=" grid grid-cols-1 lg:grid-cols-5 gap-3">
            <div className="h-60 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-60 p-3">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-60 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-60 p-3">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-60 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-60 p-3">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-60 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-60 p-3">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
            <div className="h-60 rounded-md bg-white shadow-md">
              <div className="flex items-center justify-center flex-col h-60 p-3">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/portrait-handsome-smiling-young-man-folded-arms-isolated-gray-background-joyful-cheerful-men-crossed-hands-studio-shot-172868988.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://thumbs.dreamstime.com/b/headshot-portrait-happy-millennial-man-casual-clothes-isolated-grey-studio-background-posing-smiling-young-male-shirt-165221429.jpg"
                      alt=""
                    />
                  </div>
                  <div
                    style={{ marginLeft: "-15px" }}
                    className="w-12 h-12 rounded-full overflow-hidden"
                  >
                    <img
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                      }}
                      src="https://www.westend61.de/images/0000388976pw/portrait-of-tattooed-brunette-man-in-front-of-gray-background-STKF000953.jpg"
                      alt=""
                    />
                  </div>
                </div>
                <div className="text-center pt-2">
                  <h5 className="text-pr font-medium pt-2">John Parker</h5>
                  <p className="text-gray-500 font-semibold text-sm">
                    UX, Designer
                  </p>
                </div>
                <div className="flex items-center gap-1 justify-around pt-3">
                  <div className="bg-hr w-10 text-pr font-semibold p-1 text-sm text-center rounded-2xl">
                    UI
                  </div>
                  <div className=" w-10 text-purple-900 font-semibold bg-purple-100 p-1 text-sm text-center rounded-2xl">
                    UX
                  </div>
                  <div className="bg-blue-100 text-blue-600 px-2 py-1 text-sm font-semibold text-center rounded-2xl">
                    Photoshop
                  </div>
                </div>
                <div className="flex items-center gap-1 pt-2 justify-center">
                  <div className="bg-yellow-100 w-10 text-yellow-600 font-semibold p-1 text-sm text-center rounded-2xl">
                    +7
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserManager;
