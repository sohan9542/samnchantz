import React from 'react'
import { ProgressBar } from "react-bootstrap";

import { BsThreeDotsVertical } from "react-icons/bs";
import { Menu, Transition } from "@headlessui/react";
import { Fragment } from "react";

const OutgoingProject = () => {
    const now = 60
    function classNames(...classes) {
        return classes.filter(Boolean).join(" ");
      }
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 items-center gap-2">
        <div className="mt-3 lg:col-span-9 bg-white shadow-md w-full p-3">
          <h2 className="text-pr text-2xl font-semibold">Ongoing Project</h2>
          <div className="flex pt-4 flex-col overflow-hidden">
            <div className="-my-2 overflow-x-auto h sm:-mx-6 lg:-mx-8">
              <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                <div
                  style={{ height: "300px" }}
                  className="shadow overflow-x-hidden overflow-y-scroll border-b pb-2 border-gray-200 sm:rounded-lg "
                >
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Project_Name
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Start_Date
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Due Date
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Team
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Status
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Client
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200 text-sm">
                      <tr style={{ height: "150px" }}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center">project name</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center">12/02/2012</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center">12/02/2012</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center flex items-center">
                            <img
                              src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                              className="rounded-full"
                              style={{
                                objectFit: "cover",
                                width: "30px",
                                height: "30px",
                              }}
                              alt=""
                            />
                            <img
                              src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                              className="rounded-full"
                              style={{
                                objectFit: "cover",
                                width: "30px",
                                height: "30px",
                              }}
                              alt=""
                            />
                          </p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center bg-blue-100 text-pr px-2 w-20 py-1 rounded-xl">
                            On Hold
                          </p>
                        </td>
                        <td className="whitespace-nowrap">
                          <p className="text-center">client name</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Menu
                            as="div"
                            className="relative inline-block text-left"
                          >
                            <div>
                              <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">
                                <BsThreeDotsVertical className="h-6 w-6" />
                              </Menu.Button>
                            </div>

                            <Transition
                              as={Fragment}
                              enter="transition ease-out duration-100"
                              enterFrom="transform opacity-0 scale-95"
                              enterTo="transform opacity-100 scale-100"
                              leave="transition ease-in duration-75"
                              leaveFrom="transform opacity-100 scale-100"
                              leaveTo="transform opacity-0 scale-95"
                            >
                              <Menu.Items
                                style={{ marginTop: "-90px" }}
                                className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white"
                              >
                                <div className="py-1">
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        View Reports
                                      </a>
                                    )}
                                  </Menu.Item>
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Edit Reports
                                      </a>
                                    )}
                                  </Menu.Item>
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Statistics
                                      </a>
                                    )}
                                  </Menu.Item>

                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Export to PDF
                                      </a>
                                    )}
                                  </Menu.Item>
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Export to CSV
                                      </a>
                                    )}
                                  </Menu.Item>
                                </div>
                              </Menu.Items>
                            </Transition>
                          </Menu>
                        </td>
                      </tr>
                      <tr style={{ height: "150px" }}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center">project name</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center">12/02/2012</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center">12/02/2012</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center flex items-center">
                            <img
                              src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                              className="rounded-full"
                              style={{
                                objectFit: "cover",
                                width: "30px",
                                height: "30px",
                              }}
                              alt=""
                            />
                            <img
                              src="https://thumbs.dreamstime.com/b/handsome-man-hair-style-beard-beauty-face-portrait-fashion-male-model-black-hair-high-resolution-handsome-man-125031765.jpg"
                              className="rounded-full"
                              style={{
                                objectFit: "cover",
                                width: "30px",
                                height: "30px",
                              }}
                              alt=""
                            />
                          </p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <p className="text-center bg-blue-100 text-pr px-2 w-20 py-1 rounded-xl">
                            On Hold
                          </p>
                        </td>
                        <td className="whitespace-nowrap">
                          <p className="text-center">client name</p>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Menu
                            as="div"
                            className="relative inline-block text-left"
                          >
                            <div>
                              <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">
                                <BsThreeDotsVertical className="h-6 w-6" />
                              </Menu.Button>
                            </div>

                            <Transition
                              as={Fragment}
                              enter="transition ease-out duration-100"
                              enterFrom="transform opacity-0 scale-95"
                              enterTo="transform opacity-100 scale-100"
                              leave="transition ease-in duration-75"
                              leaveFrom="transform opacity-100 scale-100"
                              leaveTo="transform opacity-0 scale-95"
                            >
                              <Menu.Items
                                style={{ marginTop: "-90px" }}
                                className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white"
                              >
                                <div className="py-1">
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        View Reports
                                      </a>
                                    )}
                                  </Menu.Item>
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Edit Reports
                                      </a>
                                    )}
                                  </Menu.Item>
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Statistics
                                      </a>
                                    )}
                                  </Menu.Item>

                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Export to PDF
                                      </a>
                                    )}
                                  </Menu.Item>
                                  <Menu.Item>
                                    {({ active }) => (
                                      <a
                                        href="#"
                                        className={classNames(
                                          active
                                            ? "bg-gray-100 text-gray-900"
                                            : "text-gray-700",
                                          "block px-4 py-2 text-sm"
                                        )}
                                      >
                                        Export to CSV
                                      </a>
                                    )}
                                  </Menu.Item>
                                </div>
                              </Menu.Items>
                            </Transition>
                          </Menu>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          style={{ height: "400px" }}
          className="bg-white mt-3 lg:col-span-3 shadow-md  p-3 w-full"
        >
          <div className="flex flex-col items-center justify-center gap-3 h-full w-full">
            <div className="flex items-center justify-center w-full">
              <div className="flex flex-col w-full">
                <div className="w-full flex items-center justify-between text-xs text-gray-500 pb-2">
                <h3>80%</h3>
                  <p>Project Completed </p>
                  
                </div>
                <ProgressBar className='progress6' now={now} />
              </div>
            </div>
            <div className="flex items-center justify-between w-full">
              <div className="flex flex-col w-full">
                <div className="w-full flex items-center justify-between text-xs text-gray-500 pb-2">
                <h3>90%</h3>
                  <p>Project On Going</p>
                  
                </div>
                <ProgressBar className='progress1' now={90} />
              </div>
            </div>
            <div className="flex items-center justify-between w-full">
              <div className="flex flex-col w-full">
                <div className="w-full flex items-center justify-between text-xs text-gray-500 pb-2">
                <h3>87%</h3>
                  <p>Project Up Coming</p>
                 
                </div>
                <ProgressBar className='progress4' now={87} />
              </div>
            </div>
          </div>
        </div>
      </div>
  )
}

export default OutgoingProject