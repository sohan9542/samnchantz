import React from 'react'

const Invoices = () => {
    return (
        <div className='p-3'>
            <div className="bg-white shadow-md p-2 w-full min-h-screen">
                <div className="flex items-center w-full justify-between pt-2 px-4">
                    <h1 className='text-xl uppercase text-pr'>Invoice</h1>
                    <h1 className='text-xl text-pr '>#123456</h1>
                </div>
                <div className="pt-5 px-4">
                    <h1 className="text-4xl uppercase text-pr pb-1">Receiver :</h1>
                    <div className='flex items-center justify-between'>
                        <div>
                            <h1 className='text-xl capitalize text-pr'>Memo name</h1>
                            <p className='text-sr text-sm'>user@user.com</p>
                            <p className='text-sr text-sm'>user address</p>
                          
                        </div>
                        <div>
                            <p className='text-sr text-sm'>Invoice Date: 01/01/0101</p>
                            <p className='text-sr text-sm'>Due Date: 01/01/0101</p>
                        </div>
                    </div>
                    <div className="my-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className="shadow overflow-hidden border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Id
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Item Name
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Quantity
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Unit Cost
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Total
                                            </th>



                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">

                                        <tr>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>0</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>item name</p>
                                            </td>

                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>0</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>$00</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>$00</p>
                                            </td>
                                        </tr>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className='grid grid-cols-1 lg:grid-cols-2 pt-4'>
                        <div></div>
                        <div className='border-t-2 border-pr pt-2'>
                            <div className='w-full flex items-center justify-between'>
                                <h1 className=" text-2xl font-semibold text-pr uppercase">Total Cost : </h1>
                                <h1 className=" text-2xl font-semibold text-pr uppercase">$000</h1>
                            </div>
                        </div>
                    </div>
                    <div className='flex items-start justify-end gap-3 pt-4'>
                        <button className='px-2 py-2 rounded-sm text-white bg-pr hover:bg-blue-800'>Print Invoice</button>
                        <button className='px-2 py-2 rounded-sm text-white bg-pr hover:bg-blue-800'>Send Invoice</button>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default Invoices
