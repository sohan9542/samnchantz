import React from 'react'
import { BsThreeDotsVertical } from "react-icons/bs"
import { Menu, Transition } from '@headlessui/react'
import { BsArrowRightShort } from "react-icons/bs"
import { Fragment } from 'react'
const PaymentHistory = () => {
    function classNames(...classes) {
        return classes.filter(Boolean).join(' ')
    }
    return (
        <div className='p-3'>
            <div className='bg-white shadow-md p-2 w-full min-h-screen'>
                <div className="flex pt-4 flex-col overflow-hidden">
                    <h1 className='text-center text-xl text-pr w-full pb-4 flex items-center justify-center gap-1'>Payment History <BsArrowRightShort/></h1>
                    <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                            <div className="shadow overflow-hidden border-b pb-2 border-gray-200 sm:rounded-lg">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Session Id
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Listing
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                               Buyer
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Seller
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Amount
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Date
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Status
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Project Review
                                            </th>
                                            <th
                                                scope="col"
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                Action
                                            </th>
                                        

                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">

                                        <tr>

                                          
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>xxxxxxxxxxxxxxxxxxxxxxxxxx</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>listing</p>
                                            </td>
                                    
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>buyer name</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>seller name</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>$00</p>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p>01/01/2020</p>
                                            </td>
                                      
                                            <td className="py-4 whitespace-nowrap">
                                                <select
                                                    className="block w-full border border-gray-300 text-sr bg-white px-2 py-1 shadow-sm sm:text-sm"
                                                >
                                                   
                                                    <option>On Hold</option>
                                                    <option>Paid</option>
                                                    <option>Failed</option>
                                                    <option>Refunded</option>

                                                </select>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <p className=' text-xs px-2 py-1 rounded-md text-center bg-pr text-white'>Review!</p>
                                            </td>
                                      
                                    
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <Menu as="div" className="relative inline-block text-left">
                                                    <div>
                                                        <Menu.Button className=" flex items-center justify-center bg-white text-pr p-1">

                                                            <BsThreeDotsVertical className='h-6 w-6' />
                                                        </Menu.Button>
                                                    </div>

                                                    <Transition
                                                        as={Fragment}
                                                        enter="transition ease-out duration-100"
                                                        enterFrom="transform opacity-0 scale-95"
                                                        enterTo="transform opacity-100 scale-100"
                                                        leave="transition ease-in duration-75"
                                                        leaveFrom="transform opacity-100 scale-100"
                                                        leaveTo="transform opacity-0 scale-95"
                                                    >
                                                        <Menu.Items style={{ marginTop:"-120px"}} className="origin-top-right absolute right-0 w-40 z-50 rounded-md shadow-lg bg-white">
                                                            <div className="py-1">
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Details
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Edit
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>
                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Delete
                                                                        </a>
                                                                    )}
                                                                </Menu.Item>

                                                                <Menu.Item>
                                                                    {({ active }) => (
                                                                        <a
                                                                            href="#"
                                                                            className={classNames(
                                                                                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                                                                                'block px-4 py-2 text-sm'
                                                                            )}
                                                                        >
                                                                            Share                                                    </a>
                                                                    )}
                                                                </Menu.Item>

                                                            </div>
                                                        </Menu.Items>
                                                    </Transition>
                                                </Menu>
                                            </td>



                                        </tr>
                                      

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    )
}

export default PaymentHistory
